<?php
if (!function_exists('__1e754f5e382b097f0c4fe5769d9b2100')):
function __1e754f5e382b097f0c4fe5769d9b2100($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
extract(Flux::forwardedAttributes($attributes, [
    'tooltipPosition',
    'tooltipKbd',
    'tooltip',
]));
?>

<?php $tooltipPosition = $tooltipPosition ??= $attributes->pluck('tooltip:position'); ?>
<?php $tooltipKbd = $tooltipKbd ??= $attributes->pluck('tooltip:kbd'); ?>
<?php $tooltip = $tooltip ??= $attributes->pluck('tooltip'); ?>

<?php
$__defaults = [
    'tooltipPosition' => 'top',
    'tooltipKbd' => null,
    'tooltip' => null,
];
$tooltipPosition ??= $attributes['tooltip-position'] ?? $attributes['tooltipPosition'] ?? $__defaults['tooltipPosition']; unset($attributes['tooltipPosition'], $attributes['tooltip-position']);
$tooltipKbd ??= $attributes['tooltip-kbd'] ?? $attributes['tooltipKbd'] ?? $__defaults['tooltipKbd']; unset($attributes['tooltipKbd'], $attributes['tooltip-kbd']);
$tooltip ??= $attributes['tooltip'] ?? $__defaults['tooltip']; unset($attributes['tooltip']);
unset($__defaults);
?>

<?php if ($tooltip): ?>
    <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/index.blade.php', $__blaze->compiledPath.'/c625b9de61ebb9f943e2dc0045327782.php'); ?>
<?php if (isset($__slotsc625b9de61ebb9f943e2dc0045327782)) { $__slotsStackc625b9de61ebb9f943e2dc0045327782[] = $__slotsc625b9de61ebb9f943e2dc0045327782; } ?>
<?php if (isset($__attrsc625b9de61ebb9f943e2dc0045327782)) { $__attrsStackc625b9de61ebb9f943e2dc0045327782[] = $__attrsc625b9de61ebb9f943e2dc0045327782; } ?>
<?php $__attrsc625b9de61ebb9f943e2dc0045327782 = ['content' => $tooltip,'position' => $tooltipPosition,'kbd' => $tooltipKbd]; ?>
<?php $__slotsc625b9de61ebb9f943e2dc0045327782 = []; ?>
<?php $__blaze->pushData($__attrsc625b9de61ebb9f943e2dc0045327782); ?>
<?php ob_start(); ?>
        <?php echo e($slot); ?>

    <?php $__slotsc625b9de61ebb9f943e2dc0045327782['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotsc625b9de61ebb9f943e2dc0045327782); ?>
<?php __c625b9de61ebb9f943e2dc0045327782($__blaze, $__attrsc625b9de61ebb9f943e2dc0045327782, $__slotsc625b9de61ebb9f943e2dc0045327782, ['content', 'position', 'kbd'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackc625b9de61ebb9f943e2dc0045327782)) { $__slotsc625b9de61ebb9f943e2dc0045327782 = array_pop($__slotsStackc625b9de61ebb9f943e2dc0045327782); } ?>
<?php if (! empty($__attrsStackc625b9de61ebb9f943e2dc0045327782)) { $__attrsc625b9de61ebb9f943e2dc0045327782 = array_pop($__attrsStackc625b9de61ebb9f943e2dc0045327782); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php echo e($slot); ?>

<?php endif; ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/with-tooltip.blade.php ENDPATH**/ ?>