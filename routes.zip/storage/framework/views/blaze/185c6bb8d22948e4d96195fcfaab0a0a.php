<?php
if (!function_exists('__185c6bb8d22948e4d96195fcfaab0a0a')):
function __185c6bb8d22948e4d96195fcfaab0a0a($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;

if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'name' => $attributes->whereStartsWith('wire:model')->first(),
];
$name ??= $attributes['name'] ?? $__defaults['name']; unset($attributes['name']);
unset($__defaults);
?>

<?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/with-inline-field.blade.php', $__blaze->compiledPath.'/16bff779d38f84642d178527a5fc0f27.php'); ?>
<?php if (isset($__slots16bff779d38f84642d178527a5fc0f27)) { $__slotsStack16bff779d38f84642d178527a5fc0f27[] = $__slots16bff779d38f84642d178527a5fc0f27; } ?>
<?php if (isset($__attrs16bff779d38f84642d178527a5fc0f27)) { $__attrsStack16bff779d38f84642d178527a5fc0f27[] = $__attrs16bff779d38f84642d178527a5fc0f27; } ?>
<?php $__attrs16bff779d38f84642d178527a5fc0f27 = ['variant' => 'inline','attributes' => $attributes]; ?>
<?php $__slots16bff779d38f84642d178527a5fc0f27 = []; ?>
<?php $__blaze->pushData($__attrs16bff779d38f84642d178527a5fc0f27); ?>
<?php ob_start(); ?>
    
    
    
    <ui-radio <?php echo e($attributes->class('flex size-[1.125rem] rounded-full mt-px outline-offset-2')); ?> data-flux-control data-flux-radio tabindex="-1">
        <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/radio/indicator.blade.php', $__blaze->compiledPath.'/835731be307d73fa5af7861670b09bc6.php'); ?>
<?php $__blaze->pushData([]); ?>
<?php __835731be307d73fa5af7861670b09bc6($__blaze, [], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
    </ui-radio>
<?php $__slots16bff779d38f84642d178527a5fc0f27['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots16bff779d38f84642d178527a5fc0f27); ?>
<?php __16bff779d38f84642d178527a5fc0f27($__blaze, $__attrs16bff779d38f84642d178527a5fc0f27, $__slots16bff779d38f84642d178527a5fc0f27, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack16bff779d38f84642d178527a5fc0f27)) { $__slots16bff779d38f84642d178527a5fc0f27 = array_pop($__slotsStack16bff779d38f84642d178527a5fc0f27); } ?>
<?php if (! empty($__attrsStack16bff779d38f84642d178527a5fc0f27)) { $__attrs16bff779d38f84642d178527a5fc0f27 = array_pop($__attrsStack16bff779d38f84642d178527a5fc0f27); } ?>
<?php $__blaze->popData(); ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/radio/variants/default.blade.php ENDPATH**/ ?>