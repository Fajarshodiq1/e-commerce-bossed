<?php
if (!function_exists('__16bff779d38f84642d178527a5fc0f27')):
function __16bff779d38f84642d178527a5fc0f27($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
extract(Flux::forwardedattributes($attributes, [
    'name',
    'description',
    'label',
]));
?>

<?php
$__defaults = [
    'name' => $attributes->whereStartsWith('wire:model')->first(),
    'description' => null,
    'label' => null,
];
$name ??= $attributes['name'] ?? $__defaults['name']; unset($attributes['name']);
$description ??= $attributes['description'] ?? $__defaults['description']; unset($attributes['description']);
$label ??= $attributes['label'] ?? $__defaults['label']; unset($attributes['label']);
unset($__defaults);
?>

<?php if (isset($label) || isset($description)): ?>
    <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/field.blade.php', $__blaze->compiledPath.'/84dfb354c291e8305aad092b23300993.php'); ?>
<?php if (isset($__slots84dfb354c291e8305aad092b23300993)) { $__slotsStack84dfb354c291e8305aad092b23300993[] = $__slots84dfb354c291e8305aad092b23300993; } ?>
<?php if (isset($__attrs84dfb354c291e8305aad092b23300993)) { $__attrsStack84dfb354c291e8305aad092b23300993[] = $__attrs84dfb354c291e8305aad092b23300993; } ?>
<?php $__attrs84dfb354c291e8305aad092b23300993 = ['variant' => 'inline']; ?>
<?php $__slots84dfb354c291e8305aad092b23300993 = []; ?>
<?php $__blaze->pushData($__attrs84dfb354c291e8305aad092b23300993); ?>
<?php ob_start(); ?>
        <?php echo e($slot); ?>


        <?php if (isset($label)): ?>
            <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/label.blade.php', $__blaze->compiledPath.'/fbc69356132c75ad44b4a1c264016ed3.php'); ?>
<?php if (isset($__slotsfbc69356132c75ad44b4a1c264016ed3)) { $__slotsStackfbc69356132c75ad44b4a1c264016ed3[] = $__slotsfbc69356132c75ad44b4a1c264016ed3; } ?>
<?php if (isset($__attrsfbc69356132c75ad44b4a1c264016ed3)) { $__attrsStackfbc69356132c75ad44b4a1c264016ed3[] = $__attrsfbc69356132c75ad44b4a1c264016ed3; } ?>
<?php $__attrsfbc69356132c75ad44b4a1c264016ed3 = []; ?>
<?php $__slotsfbc69356132c75ad44b4a1c264016ed3 = []; ?>
<?php $__blaze->pushData($__attrsfbc69356132c75ad44b4a1c264016ed3); ?>
<?php ob_start(); ?><?php echo e($label); ?><?php $__slotsfbc69356132c75ad44b4a1c264016ed3['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotsfbc69356132c75ad44b4a1c264016ed3); ?>
<?php __fbc69356132c75ad44b4a1c264016ed3($__blaze, $__attrsfbc69356132c75ad44b4a1c264016ed3, $__slotsfbc69356132c75ad44b4a1c264016ed3, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackfbc69356132c75ad44b4a1c264016ed3)) { $__slotsfbc69356132c75ad44b4a1c264016ed3 = array_pop($__slotsStackfbc69356132c75ad44b4a1c264016ed3); } ?>
<?php if (! empty($__attrsStackfbc69356132c75ad44b4a1c264016ed3)) { $__attrsfbc69356132c75ad44b4a1c264016ed3 = array_pop($__attrsStackfbc69356132c75ad44b4a1c264016ed3); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>

        <?php if (isset($description)): ?>
            <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/description.blade.php', $__blaze->compiledPath.'/3a05f68d4f7e6190e13615cddff34fb9.php'); ?>
<?php if (isset($__slots3a05f68d4f7e6190e13615cddff34fb9)) { $__slotsStack3a05f68d4f7e6190e13615cddff34fb9[] = $__slots3a05f68d4f7e6190e13615cddff34fb9; } ?>
<?php if (isset($__attrs3a05f68d4f7e6190e13615cddff34fb9)) { $__attrsStack3a05f68d4f7e6190e13615cddff34fb9[] = $__attrs3a05f68d4f7e6190e13615cddff34fb9; } ?>
<?php $__attrs3a05f68d4f7e6190e13615cddff34fb9 = []; ?>
<?php $__slots3a05f68d4f7e6190e13615cddff34fb9 = []; ?>
<?php $__blaze->pushData($__attrs3a05f68d4f7e6190e13615cddff34fb9); ?>
<?php ob_start(); ?><?php echo e($description); ?><?php $__slots3a05f68d4f7e6190e13615cddff34fb9['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots3a05f68d4f7e6190e13615cddff34fb9); ?>
<?php __3a05f68d4f7e6190e13615cddff34fb9($__blaze, $__attrs3a05f68d4f7e6190e13615cddff34fb9, $__slots3a05f68d4f7e6190e13615cddff34fb9, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack3a05f68d4f7e6190e13615cddff34fb9)) { $__slots3a05f68d4f7e6190e13615cddff34fb9 = array_pop($__slotsStack3a05f68d4f7e6190e13615cddff34fb9); } ?>
<?php if (! empty($__attrsStack3a05f68d4f7e6190e13615cddff34fb9)) { $__attrs3a05f68d4f7e6190e13615cddff34fb9 = array_pop($__attrsStack3a05f68d4f7e6190e13615cddff34fb9); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>

        [STARTCOMPILEDUNBLAZE:i0ylw9SKvu]<?php \Livewire\Blaze\Unblaze::storeScope("i0ylw9SKvu", scope: ['name' => $name]) ?>[ENDCOMPILEDUNBLAZE:i0ylw9SKvu]
    <?php $__slots84dfb354c291e8305aad092b23300993['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots84dfb354c291e8305aad092b23300993); ?>
<?php __84dfb354c291e8305aad092b23300993($__blaze, $__attrs84dfb354c291e8305aad092b23300993, $__slots84dfb354c291e8305aad092b23300993, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack84dfb354c291e8305aad092b23300993)) { $__slots84dfb354c291e8305aad092b23300993 = array_pop($__slotsStack84dfb354c291e8305aad092b23300993); } ?>
<?php if (! empty($__attrsStack84dfb354c291e8305aad092b23300993)) { $__attrs84dfb354c291e8305aad092b23300993 = array_pop($__attrsStack84dfb354c291e8305aad092b23300993); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php echo e($slot); ?>

<?php endif; ?>

<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/with-inline-field.blade.php ENDPATH**/ ?>