<?php
if (!function_exists('__1be55a10275d873ac0f50ec1841d8ccd')):
function __1be55a10275d873ac0f50ec1841d8ccd($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$classes = Flux::classes('[grid-area:footer]')
    ->add($attributes->has('container') ? '' : 'p-6 lg:p-8')
    ;
?>

<div <?php echo e($attributes->class($classes)); ?> data-flux-footer>
    <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/with-container.blade.php', $__blaze->compiledPath.'/e740f4c8a297a3f37c366cfe9e6f85e7.php'); ?>
<?php if (isset($__slotse740f4c8a297a3f37c366cfe9e6f85e7)) { $__slotsStacke740f4c8a297a3f37c366cfe9e6f85e7[] = $__slotse740f4c8a297a3f37c366cfe9e6f85e7; } ?>
<?php if (isset($__attrse740f4c8a297a3f37c366cfe9e6f85e7)) { $__attrsStacke740f4c8a297a3f37c366cfe9e6f85e7[] = $__attrse740f4c8a297a3f37c366cfe9e6f85e7; } ?>
<?php $__attrse740f4c8a297a3f37c366cfe9e6f85e7 = ['attributes' => $attributes->except('class')->class('p-6 lg:p-8')]; ?>
<?php $__slotse740f4c8a297a3f37c366cfe9e6f85e7 = []; ?>
<?php $__blaze->pushData($__attrse740f4c8a297a3f37c366cfe9e6f85e7); ?>
<?php ob_start(); ?>
        <?php echo e($slot); ?>

    <?php $__slotse740f4c8a297a3f37c366cfe9e6f85e7['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotse740f4c8a297a3f37c366cfe9e6f85e7); ?>
<?php __e740f4c8a297a3f37c366cfe9e6f85e7($__blaze, $__attrse740f4c8a297a3f37c366cfe9e6f85e7, $__slotse740f4c8a297a3f37c366cfe9e6f85e7, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStacke740f4c8a297a3f37c366cfe9e6f85e7)) { $__slotse740f4c8a297a3f37c366cfe9e6f85e7 = array_pop($__slotsStacke740f4c8a297a3f37c366cfe9e6f85e7); } ?>
<?php if (! empty($__attrsStacke740f4c8a297a3f37c366cfe9e6f85e7)) { $__attrse740f4c8a297a3f37c366cfe9e6f85e7 = array_pop($__attrsStacke740f4c8a297a3f37c366cfe9e6f85e7); } ?>
<?php $__blaze->popData(); ?>
</div>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/footer.blade.php ENDPATH**/ ?>