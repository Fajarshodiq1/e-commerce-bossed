<?php
if (!function_exists('__e740f4c8a297a3f37c366cfe9e6f85e7')):
function __e740f4c8a297a3f37c366cfe9e6f85e7($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'container' => null,
];
$container ??= $attributes['container'] ?? $__defaults['container']; unset($attributes['container']);
unset($__defaults);
?>

<?php if ($container): ?>
    <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/container.blade.php', $__blaze->compiledPath.'/d496cd24d7e3e1a88c1b14f34131a52c.php'); ?>
<?php if (isset($__slotsd496cd24d7e3e1a88c1b14f34131a52c)) { $__slotsStackd496cd24d7e3e1a88c1b14f34131a52c[] = $__slotsd496cd24d7e3e1a88c1b14f34131a52c; } ?>
<?php if (isset($__attrsd496cd24d7e3e1a88c1b14f34131a52c)) { $__attrsStackd496cd24d7e3e1a88c1b14f34131a52c[] = $__attrsd496cd24d7e3e1a88c1b14f34131a52c; } ?>
<?php $__attrsd496cd24d7e3e1a88c1b14f34131a52c = ['class' => $attributes->get('class')]; ?>
<?php $__slotsd496cd24d7e3e1a88c1b14f34131a52c = []; ?>
<?php $__blaze->pushData($__attrsd496cd24d7e3e1a88c1b14f34131a52c); ?>
<?php ob_start(); ?>
        <?php echo e($slot); ?>

    <?php $__slotsd496cd24d7e3e1a88c1b14f34131a52c['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slotsd496cd24d7e3e1a88c1b14f34131a52c); ?>
<?php __d496cd24d7e3e1a88c1b14f34131a52c($__blaze, $__attrsd496cd24d7e3e1a88c1b14f34131a52c, $__slotsd496cd24d7e3e1a88c1b14f34131a52c, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackd496cd24d7e3e1a88c1b14f34131a52c)) { $__slotsd496cd24d7e3e1a88c1b14f34131a52c = array_pop($__slotsStackd496cd24d7e3e1a88c1b14f34131a52c); } ?>
<?php if (! empty($__attrsStackd496cd24d7e3e1a88c1b14f34131a52c)) { $__attrsd496cd24d7e3e1a88c1b14f34131a52c = array_pop($__attrsStackd496cd24d7e3e1a88c1b14f34131a52c); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php echo e($slot); ?>

<?php endif; ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/with-container.blade.php ENDPATH**/ ?>