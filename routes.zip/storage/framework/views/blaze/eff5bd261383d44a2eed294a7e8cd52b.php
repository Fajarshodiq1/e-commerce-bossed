<?php
if (!function_exists('__eff5bd261383d44a2eed294a7e8cd52b')):
function __eff5bd261383d44a2eed294a7e8cd52b($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'name' => $attributes->whereStartsWith('wire:model')->first(),
    'resize' => 'vertical',
    'invalid' => null,
    'rows' => 4,
];
$name ??= $attributes['name'] ?? $__defaults['name']; unset($attributes['name']);
$resize ??= $attributes['resize'] ?? $__defaults['resize']; unset($attributes['resize']);
$invalid ??= $attributes['invalid'] ?? $__defaults['invalid']; unset($attributes['invalid']);
$rows ??= $attributes['rows'] ?? $__defaults['rows']; unset($attributes['rows']);
unset($__defaults);
?>

<?php
$classes = Flux::classes()
    ->add('block p-3 w-full')
    ->add('shadow-xs disabled:shadow-none border rounded-lg')
    ->add('bg-white dark:bg-white/10 dark:disabled:bg-white/[7%]')
    ->add($resize ? match ($resize) {
        'none' => 'resize-none',
        'both' => 'resize',
        'horizontal' => 'resize-x',
        'vertical' => 'resize-y',
        default => 'resize-y',
    } : 'resize-none')
    ->add($rows === 'auto' ? 'field-sizing-content' : '')
    ->add('text-base sm:text-sm text-zinc-700 disabled:text-zinc-500 placeholder-zinc-400 disabled:placeholder-zinc-400/70 dark:text-zinc-300 dark:disabled:text-zinc-400 dark:placeholder-zinc-400 dark:disabled:placeholder-zinc-500')
    ->add('border-zinc-200 border-b-zinc-300/80 dark:border-white/10')
    ->add('data-invalid:shadow-none data-invalid:border-red-500 dark:data-invalid:border-red-500')
    ;
?>

<?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/with-field.blade.php', $__blaze->compiledPath.'/49faab1b9f3fe9cd5c4d8c3583f47b36.php'); ?>
<?php if (isset($__slots49faab1b9f3fe9cd5c4d8c3583f47b36)) { $__slotsStack49faab1b9f3fe9cd5c4d8c3583f47b36[] = $__slots49faab1b9f3fe9cd5c4d8c3583f47b36; } ?>
<?php if (isset($__attrs49faab1b9f3fe9cd5c4d8c3583f47b36)) { $__attrsStack49faab1b9f3fe9cd5c4d8c3583f47b36[] = $__attrs49faab1b9f3fe9cd5c4d8c3583f47b36; } ?>
<?php $__attrs49faab1b9f3fe9cd5c4d8c3583f47b36 = ['attributes' => $attributes]; ?>
<?php $__slots49faab1b9f3fe9cd5c4d8c3583f47b36 = []; ?>
<?php $__blaze->pushData($__attrs49faab1b9f3fe9cd5c4d8c3583f47b36); ?>
<?php ob_start(); ?>
    <textarea
        <?php echo e($attributes->class($classes)); ?>

        rows="<?php echo e($rows); ?>"
        <?php if(isset($name)): ?> name="<?php echo e($name); ?>" <?php endif; ?>
        [STARTCOMPILEDUNBLAZE:100S546ucj]<?php \Livewire\Blaze\Unblaze::storeScope("100S546ucj", scope: ['name' => $name ?? null, 'invalid' => $invalid ?? false]) ?>[ENDCOMPILEDUNBLAZE:100S546ucj]
        data-flux-control
        data-flux-textarea
    ><?php echo e($slot); ?></textarea>
<?php $__slots49faab1b9f3fe9cd5c4d8c3583f47b36['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots49faab1b9f3fe9cd5c4d8c3583f47b36); ?>
<?php __49faab1b9f3fe9cd5c4d8c3583f47b36($__blaze, $__attrs49faab1b9f3fe9cd5c4d8c3583f47b36, $__slots49faab1b9f3fe9cd5c4d8c3583f47b36, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack49faab1b9f3fe9cd5c4d8c3583f47b36)) { $__slots49faab1b9f3fe9cd5c4d8c3583f47b36 = array_pop($__slotsStack49faab1b9f3fe9cd5c4d8c3583f47b36); } ?>
<?php if (! empty($__attrsStack49faab1b9f3fe9cd5c4d8c3583f47b36)) { $__attrs49faab1b9f3fe9cd5c4d8c3583f47b36 = array_pop($__attrsStack49faab1b9f3fe9cd5c4d8c3583f47b36); } ?>
<?php $__blaze->popData(); ?>
<?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/textarea.blade.php ENDPATH**/ ?>