<?php
if (!function_exists('__5bcbcd0ff9ce422767bd4ac86b43aad8')):
function __5bcbcd0ff9ce422767bd4ac86b43aad8($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'length' => null,
    'private' => false,
];
$length ??= $attributes['length'] ?? $__defaults['length']; unset($attributes['length']);
$private ??= $attributes['private'] ?? $__defaults['private']; unset($attributes['private']);
unset($__defaults);
?>

<?php
    $classes = Flux::classes()
        ->add('flex items-center gap-2 isolate w-fit')
        ->add('[&_[data-flux-input-group]]:w-auto')
?>

<?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/with-field.blade.php', $__blaze->compiledPath.'/49faab1b9f3fe9cd5c4d8c3583f47b36.php'); ?>
<?php if (isset($__slots49faab1b9f3fe9cd5c4d8c3583f47b36)) { $__slotsStack49faab1b9f3fe9cd5c4d8c3583f47b36[] = $__slots49faab1b9f3fe9cd5c4d8c3583f47b36; } ?>
<?php if (isset($__attrs49faab1b9f3fe9cd5c4d8c3583f47b36)) { $__attrsStack49faab1b9f3fe9cd5c4d8c3583f47b36[] = $__attrs49faab1b9f3fe9cd5c4d8c3583f47b36; } ?>
<?php $__attrs49faab1b9f3fe9cd5c4d8c3583f47b36 = ['attributes' => $attributes]; ?>
<?php $__slots49faab1b9f3fe9cd5c4d8c3583f47b36 = []; ?>
<?php $__blaze->pushData($__attrs49faab1b9f3fe9cd5c4d8c3583f47b36); ?>
<?php ob_start(); ?>
    <ui-otp
        <?php echo e($attributes->class($classes)); ?>

        data-flux-otp
        data-flux-control
        role="group"
        data-flux-input-aria-label="<?php echo e(__('Character {current} of {total}')); ?>"
    >
        <?php if($slot->isEmpty() && $length): ?>
            <?php for($i = 0; $i < $length; $i++): ?>
                <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/otp/input.blade.php', $__blaze->compiledPath.'/36f059c78ae7161645c4739da044d273.php'); ?>
<?php $__blaze->pushData([]); ?>
<?php __36f059c78ae7161645c4739da044d273($__blaze, [], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
            <?php endfor; ?>
        <?php else: ?>
            <?php echo e($slot); ?>

        <?php endif; ?>
    </ui-otp>
<?php $__slots49faab1b9f3fe9cd5c4d8c3583f47b36['slot'] = new \Illuminate\View\ComponentSlot($__blaze->processPassthroughContent('trim', trim(ob_get_clean())), []); ?>
<?php $__blaze->pushSlots($__slots49faab1b9f3fe9cd5c4d8c3583f47b36); ?>
<?php __49faab1b9f3fe9cd5c4d8c3583f47b36($__blaze, $__attrs49faab1b9f3fe9cd5c4d8c3583f47b36, $__slots49faab1b9f3fe9cd5c4d8c3583f47b36, ['attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack49faab1b9f3fe9cd5c4d8c3583f47b36)) { $__slots49faab1b9f3fe9cd5c4d8c3583f47b36 = array_pop($__slotsStack49faab1b9f3fe9cd5c4d8c3583f47b36); } ?>
<?php if (! empty($__attrsStack49faab1b9f3fe9cd5c4d8c3583f47b36)) { $__attrs49faab1b9f3fe9cd5c4d8c3583f47b36 = array_pop($__attrsStack49faab1b9f3fe9cd5c4d8c3583f47b36); } ?>
<?php $__blaze->popData(); ?><?php
echo $__blaze->processPassthroughContent('ltrim', ltrim(ob_get_clean()));
} endif; ?><?php /**PATH C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/otp/index.blade.php ENDPATH**/ ?>