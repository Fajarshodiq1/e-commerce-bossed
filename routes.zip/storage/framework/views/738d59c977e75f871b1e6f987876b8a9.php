<?php # [BlazeFolded]:{flux::heading}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::subheading}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/subheading.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::badge}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/badge/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.column}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/column.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.column}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/column.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.column}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/column.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.column}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/column.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.column}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/column.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.column}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/column.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.columns}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/columns.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.cell}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/cell.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.cell}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/cell.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::link}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/link.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.cell}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/cell.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.cell}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/cell.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.cell}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/cell.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.cell}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/cell.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.row}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/row.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.cell}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/cell.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.row}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/row.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.rows}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/rows.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/index.blade.php}:{1786017876} ?>
<div class="p-6 space-y-6">
    <!-- Header Section -->
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
            <?php ob_start(); ?><h1 class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-2xl [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>Manajemen Partner / Brand<?php echo trim(ob_get_clean()); ?></h1>

        <!--[if ENDBLOCK]><![endif]--><?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><div class="text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70" data-flux-subheading>
    <?php ob_start(); ?>Kelola logo perusahaan atau brand yang bekerja sama dengan toko Anda.<?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
        </div>

        <?php ob_start(); ?><a href="<?php echo e(route('admin.partners.create')); ?>" data-flux-button="data-flux-button" class="relative items-center font-medium justify-center gap-2 whitespace-nowrap disabled:opacity-75 dark:disabled:opacity-75 disabled:cursor-default disabled:pointer-events-none justify-center h-10 text-sm rounded-lg ps-3 pe-4 inline-flex  bg-[var(--color-accent)] hover:bg-[color-mix(in_oklab,_var(--color-accent),_transparent_10%)] text-[var(--color-accent-foreground)] border border-black/10 dark:border-0 shadow-[inset_0px_1px_--theme(--color-white/.2)] [[data-flux-button-group]_&amp;]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-[1px] dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-s-[1px] [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[color-mix(in_srgb,var(--color-accent-foreground),transparent_85%)]" data-flux-group-target="data-flux-group-target">
        <svg class="shrink-0 [:where(&amp;)]:size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path d="M8.75 3.75a.75.75 0 0 0-1.5 0v3.5h-3.5a.75.75 0 0 0 0 1.5h3.5v3.5a.75.75 0 0 0 1.5 0v-3.5h3.5a.75.75 0 0 0 0-1.5h-3.5v-3.5Z"/>
</svg>

                
                    
            
            <span><?php ob_start(); ?>
            Tambah Partner Baru
        <?php echo trim(ob_get_clean()); ?></span>
    </a>
<?php echo ltrim(ob_get_clean()); ?>
    </div>

    <!-- Alert / Flash Message -->
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session()->has('message')): ?>
        <?php ob_start(); ?><div data-flux-badge="data-flux-badge" class="inline-flex items-center font-medium whitespace-nowrap  [print-color-adjust:exact] text-sm py-1.5 **:data-flux-badge-icon:me-2 rounded-md px-2 text-green-800 [&amp;_button]:text-green-800! dark:text-green-200 dark:[&amp;_button]:text-green-200! bg-green-400/20 dark:bg-green-400/40 [&amp;:is(button)]:hover:bg-green-400/30 dark:[button]:hover:bg-green-400/50 w-full justify-start py-3 px-4">
        <?php ob_start(); ?>
            <?php echo e(session('message')); ?>

        <?php echo trim(ob_get_clean()); ?>

    </div>
<?php echo ltrim(ob_get_clean()); ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <!-- Filter & Search Section -->
    <div class="w-full md:w-1/3">
        <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/input/index.blade.php', $__blaze->compiledPath.'/7d4f1be85db8dbf791d2ec038e21b28f.php'); ?>
<?php $__blaze->pushData(['wire:model.live.debounce.300ms' => 'search','type' => 'search','placeholder' => 'Cari nama partner...','icon' => 'magnifying-glass']); ?>
<?php _7d4f1be85db8dbf791d2ec038e21b28f($__blaze, ['wire:model.live.debounce.300ms' => 'search','type' => 'search','placeholder' => 'Cari nama partner...','icon' => 'magnifying-glass'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
    </div>

    <!-- Data Table -->
    <?php ob_start(); ?><div class="flex flex-col ">
    

    <ui-table-scroll-area class="overflow-auto">
        <table class="[:where(&amp;)]:min-w-full table-fixed border-separate border-spacing-0 isolate text-zinc-800 whitespace-nowrap [&amp;_dialog]:whitespace-normal [&amp;_[popover]]:whitespace-normal" data-flux-table>
            <?php ob_start(); ?>
        <?php ob_start(); ?><thead class="" data-flux-columns>
    <tr >
        <?php ob_start(); ?>
            <?php ob_start(); ?><th class="py-3 px-3 first:ps-0 last:pe-0 text-start text-sm font-medium text-zinc-800 dark:text-white border-b border-zinc-800/10 dark:border-white/20    **:data-flux-table-sortable:last:me-0" data-flux-column>
            <div class="flex in-[.group\/center-align]:justify-center in-[.group\/end-align]:justify-end"><?php ob_start(); ?>Logo<?php echo trim(ob_get_clean()); ?></div>
    </th>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><th class="py-3 px-3 first:ps-0 last:pe-0 text-start text-sm font-medium text-zinc-800 dark:text-white border-b border-zinc-800/10 dark:border-white/20    **:data-flux-table-sortable:last:me-0" data-flux-column>
            <div class="flex in-[.group\/center-align]:justify-center in-[.group\/end-align]:justify-end"><?php ob_start(); ?>Nama Perusahaan / Brand<?php echo trim(ob_get_clean()); ?></div>
    </th>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><th class="py-3 px-3 first:ps-0 last:pe-0 text-start text-sm font-medium text-zinc-800 dark:text-white border-b border-zinc-800/10 dark:border-white/20    **:data-flux-table-sortable:last:me-0" data-flux-column>
            <div class="flex in-[.group\/center-align]:justify-center in-[.group\/end-align]:justify-end"><?php ob_start(); ?>Website / URL<?php echo trim(ob_get_clean()); ?></div>
    </th>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><th class="py-3 px-3 first:ps-0 last:pe-0 text-start text-sm font-medium text-zinc-800 dark:text-white border-b border-zinc-800/10 dark:border-white/20    **:data-flux-table-sortable:last:me-0" data-flux-column>
            <div class="flex in-[.group\/center-align]:justify-center in-[.group\/end-align]:justify-end"><?php ob_start(); ?>Urutan<?php echo trim(ob_get_clean()); ?></div>
    </th>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><th class="py-3 px-3 first:ps-0 last:pe-0 text-start text-sm font-medium text-zinc-800 dark:text-white border-b border-zinc-800/10 dark:border-white/20    **:data-flux-table-sortable:last:me-0" data-flux-column>
            <div class="flex in-[.group\/center-align]:justify-center in-[.group\/end-align]:justify-end"><?php ob_start(); ?>Status<?php echo trim(ob_get_clean()); ?></div>
    </th>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><th class="py-3 px-3 first:ps-0 last:pe-0 text-start text-sm font-medium text-zinc-800 dark:text-white border-b border-zinc-800/10 dark:border-white/20    **:data-flux-table-sortable:last:me-0 text-right" data-flux-column>
            <div class="flex in-[.group\/center-align]:justify-center in-[.group\/end-align]:justify-end"><?php ob_start(); ?>Aksi<?php echo trim(ob_get_clean()); ?></div>
    </th>
<?php echo ltrim(ob_get_clean()); ?>
        <?php echo trim(ob_get_clean()); ?>

    </tr>
</thead>
<?php echo ltrim(ob_get_clean()); ?>

        <?php ob_start(); ?><tbody  data-flux-rows>
    <?php ob_start(); ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php ob_start(); ?><tr  <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'table-'.e($partner->id).''; ?>wire:key="table-<?php echo e($partner->id); ?>"  class="" data-flux-row>
    <?php ob_start(); ?>
                    <!-- Column: Logo -->
                    <?php ob_start(); ?><td class="[:where(&amp;)]:py-3 [:where(&amp;)]:px-3 first:ps-0 last:pe-0 text-sm  text-zinc-500 dark:text-zinc-300  not-in-[tr:first-child]:border-t border-zinc-800/10 dark:border-white/20" data-flux-cell>
    <?php ob_start(); ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($partner->logo): ?>
                            <img src="<?php echo e(asset('storage/' . $partner->logo)); ?>" alt="<?php echo e($partner->name); ?>"
                                class="h-10 object-contain max-w-[120px] rounded border border-zinc-200 dark:border-zinc-700 p-1 bg-white dark:bg-zinc-800">
                        <?php else: ?>
                            <div
                                class="w-10 h-10 bg-zinc-100 dark:bg-zinc-800 rounded flex items-center justify-center text-xs text-zinc-400">
                                No Logo
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php echo trim(ob_get_clean()); ?>

</td>
<?php echo ltrim(ob_get_clean()); ?>

                    <!-- Column: Nama -->
                    <?php ob_start(); ?><td class="[:where(&amp;)]:py-3 [:where(&amp;)]:px-3 first:ps-0 last:pe-0 text-sm  text-zinc-500 dark:text-zinc-300  not-in-[tr:first-child]:border-t border-zinc-800/10 dark:border-white/20 font-medium text-zinc-800 dark:text-zinc-200" data-flux-cell>
    <?php ob_start(); ?>
                        <?php echo e($partner->name); ?>

                    <?php echo trim(ob_get_clean()); ?>

</td>
<?php echo ltrim(ob_get_clean()); ?>

                    <!-- Column: Website / URL -->
                    <?php ob_start(); ?><td class="[:where(&amp;)]:py-3 [:where(&amp;)]:px-3 first:ps-0 last:pe-0 text-sm  text-zinc-500 dark:text-zinc-300  not-in-[tr:first-child]:border-t border-zinc-800/10 dark:border-white/20 text-sm text-zinc-500 dark:text-zinc-400" data-flux-cell>
    <?php ob_start(); ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($partner->url): ?>
                            <?php ob_start(); ?><a class="inline font-medium underline-offset-[6px] hover:decoration-current underline [[data-color]&gt;&amp;]:text-inherit [[data-color]&gt;&amp;]:decoration-current/20 dark:[[data-color]&gt;&amp;]:decoration-current/50 [[data-color]&gt;&amp;]:hover:decoration-current text-[var(--color-accent-content)] decoration-[color-mix(in_oklab,var(--color-accent-content),transparent_80%)]" href="<?php echo e($partner->url); ?>" target="_blank" icon-trailing="arrow-up-right" data-flux-link ><?php ob_start(); ?>
                                <?php echo e(Str::limit($partner->url, 30)); ?>

                            <?php echo trim(ob_get_clean()); ?></a><?php echo ltrim(ob_get_clean()); ?>
                        <?php else: ?>
                            <span class="text-zinc-400 dark:text-zinc-600">-</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php echo trim(ob_get_clean()); ?>

</td>
<?php echo ltrim(ob_get_clean()); ?>

                    <!-- Column: Urutan -->
                    <?php ob_start(); ?><td class="[:where(&amp;)]:py-3 [:where(&amp;)]:px-3 first:ps-0 last:pe-0 text-sm  text-zinc-500 dark:text-zinc-300  not-in-[tr:first-child]:border-t border-zinc-800/10 dark:border-white/20 text-zinc-600 dark:text-zinc-400 text-sm" data-flux-cell>
    <?php ob_start(); ?>
                        <?php echo e($partner->sort_order); ?>

                    <?php echo trim(ob_get_clean()); ?>

</td>
<?php echo ltrim(ob_get_clean()); ?>

                    <!-- Column: Status Toggle Badge -->
                    <?php ob_start(); ?><td class="[:where(&amp;)]:py-3 [:where(&amp;)]:px-3 first:ps-0 last:pe-0 text-sm  text-zinc-500 dark:text-zinc-300  not-in-[tr:first-child]:border-t border-zinc-800/10 dark:border-white/20" data-flux-cell>
    <?php ob_start(); ?>
                        <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/badge/index.blade.php', $__blaze->compiledPath.'/aa9aee5690195ad59a27c489c2c00729.php'); ?>
<?php if (isset($__slotsaa9aee5690195ad59a27c489c2c00729)) { $__slotsStackaa9aee5690195ad59a27c489c2c00729[] = $__slotsaa9aee5690195ad59a27c489c2c00729; } ?>
<?php if (isset($__attrsaa9aee5690195ad59a27c489c2c00729)) { $__attrsStackaa9aee5690195ad59a27c489c2c00729[] = $__attrsaa9aee5690195ad59a27c489c2c00729; } ?>
<?php $__attrsaa9aee5690195ad59a27c489c2c00729 = ['as' => 'button','wire:click' => 'toggleActive('.e($partner->id).')','color' => e($partner->is_active ? 'green' : 'zinc'),'size' => 'sm','class' => 'cursor-pointer hover:opacity-80 transition']; ?>
<?php $__slotsaa9aee5690195ad59a27c489c2c00729 = []; ?>
<?php $__blaze->pushData($__attrsaa9aee5690195ad59a27c489c2c00729); ?>
<?php ob_start(); ?>
                            <?php echo e($partner->is_active ? 'Aktif' : 'Sembunyi'); ?>

                        <?php $__slotsaa9aee5690195ad59a27c489c2c00729['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsaa9aee5690195ad59a27c489c2c00729); ?>
<?php _aa9aee5690195ad59a27c489c2c00729($__blaze, $__attrsaa9aee5690195ad59a27c489c2c00729, $__slotsaa9aee5690195ad59a27c489c2c00729, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackaa9aee5690195ad59a27c489c2c00729)) { $__slotsaa9aee5690195ad59a27c489c2c00729 = array_pop($__slotsStackaa9aee5690195ad59a27c489c2c00729); } ?>
<?php if (! empty($__attrsStackaa9aee5690195ad59a27c489c2c00729)) { $__attrsaa9aee5690195ad59a27c489c2c00729 = array_pop($__attrsStackaa9aee5690195ad59a27c489c2c00729); } ?>
<?php $__blaze->popData(); ?>
                    <?php echo trim(ob_get_clean()); ?>

</td>
<?php echo ltrim(ob_get_clean()); ?>

                    <!-- Column: Action Buttons -->
                    <?php ob_start(); ?><td class="[:where(&amp;)]:py-3 [:where(&amp;)]:px-3 first:ps-0 last:pe-0 text-sm  text-zinc-500 dark:text-zinc-300  not-in-[tr:first-child]:border-t border-zinc-800/10 dark:border-white/20 text-right" data-flux-cell>
    <?php ob_start(); ?>
                        <div class="flex justify-end gap-2">
                            <?php ob_start(); ?><a href="<?php echo e(route('admin.partners.edit', $partner->id)); ?>" data-flux-button="data-flux-button" class="relative items-center font-medium justify-center gap-2 whitespace-nowrap disabled:opacity-75 dark:disabled:opacity-75 disabled:cursor-default disabled:pointer-events-none justify-center h-8 text-sm rounded-md px-3 inline-flex  bg-transparent hover:bg-zinc-800/5 dark:hover:bg-white/15 text-zinc-800 dark:text-white">
        <svg class="shrink-0 [:where(&amp;)]:size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path fill-rule="evenodd" d="M11.013 2.513a1.75 1.75 0 0 1 2.475 2.474L6.226 12.25a2.751 2.751 0 0 1-.892.596l-2.047.848a.75.75 0 0 1-.98-.98l.848-2.047a2.75 2.75 0 0 1 .596-.892l7.262-7.261Z" clip-rule="evenodd"/>
</svg>

                
                    
            
            <span><?php ob_start(); ?>
                                Edit
                            <?php echo trim(ob_get_clean()); ?></span>
    </a>
<?php echo ltrim(ob_get_clean()); ?>

                            <?php ob_start(); ?><button type="button" class="relative items-center font-medium justify-center gap-2 whitespace-nowrap disabled:opacity-75 dark:disabled:opacity-75 disabled:cursor-default disabled:pointer-events-none justify-center h-8 text-sm rounded-md px-3 inline-flex  bg-red-500 hover:bg-red-600 dark:bg-red-600 dark:hover:bg-red-500 text-white  shadow-[inset_0px_1px_var(--color-red-500),inset_0px_2px_--theme(--color-white/.15)] dark:shadow-none [[data-flux-button-group]_&amp;]:border-e [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 [[data-flux-button-group]_&amp;]:border-red-600 dark:[[data-flux-button-group]_&amp;]:border-red-900/25 *:transition-opacity [&amp;[data-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-flux-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-loading]&gt;[data-flux-loading-indicator]]:opacity-100 [&amp;[data-flux-loading]&gt;[data-flux-loading-indicator]]:opacity-100 data-loading:pointer-events-none data-flux-loading:pointer-events-none" data-flux-button="data-flux-button" data-flux-group-target="data-flux-group-target" wire:target="delete(<?php echo e($partner->id); ?>)" wire:loading.attr="data-flux-loading" wire:click="delete(<?php echo e($partner->id); ?>)" wire:confirm="Yakin ingin menghapus partner ini?">
        <div class="absolute inset-0 flex items-center justify-center opacity-0" data-flux-loading-indicator>
                <svg class="shrink-0 [:where(&amp;)]:size-4 animate-spin" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true" data-slot="icon">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
</svg>
                    </div>
        
                    <svg class="shrink-0 [:where(&amp;)]:size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path fill-rule="evenodd" d="M5 3.25V4H2.75a.75.75 0 0 0 0 1.5h.3l.815 8.15A1.5 1.5 0 0 0 5.357 15h5.285a1.5 1.5 0 0 0 1.493-1.35l.815-8.15h.3a.75.75 0 0 0 0-1.5H11v-.75A2.25 2.25 0 0 0 8.75 1h-1.5A2.25 2.25 0 0 0 5 3.25Zm2.25-.75a.75.75 0 0 0-.75.75V4h3v-.75a.75.75 0 0 0-.75-.75h-1.5ZM6.05 6a.75.75 0 0 1 .787.713l.275 5.5a.75.75 0 0 1-1.498.075l-.275-5.5A.75.75 0 0 1 6.05 6Zm3.9 0a.75.75 0 0 1 .712.787l-.275 5.5a.75.75 0 0 1-1.498-.075l.275-5.5a.75.75 0 0 1 .786-.711Z" clip-rule="evenodd"/>
</svg>

                
                    
            
            <span><?php ob_start(); ?>
                                Hapus
                            <?php echo trim(ob_get_clean()); ?></span>
    </button>
<?php echo ltrim(ob_get_clean()); ?>
                        </div>
                    <?php echo trim(ob_get_clean()); ?>

</td>
<?php echo ltrim(ob_get_clean()); ?>
                <?php echo trim(ob_get_clean()); ?>

</tr>
<?php echo ltrim(ob_get_clean()); ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <?php ob_start(); ?><tr  class="" data-flux-row>
    <?php ob_start(); ?>
                    <?php ob_start(); ?><td class="[:where(&amp;)]:py-3 [:where(&amp;)]:px-3 first:ps-0 last:pe-0 text-sm  text-zinc-500 dark:text-zinc-300  not-in-[tr:first-child]:border-t border-zinc-800/10 dark:border-white/20 text-center py-6 text-zinc-500 dark:text-zinc-400" colspan="6" data-flux-cell>
    <?php ob_start(); ?>
                        Belum ada data partner.
                    <?php echo trim(ob_get_clean()); ?>

</td>
<?php echo ltrim(ob_get_clean()); ?>
                <?php echo trim(ob_get_clean()); ?>

</tr>
<?php echo ltrim(ob_get_clean()); ?>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php echo trim(ob_get_clean()); ?>

</tbody>
<?php echo ltrim(ob_get_clean()); ?>
    <?php echo trim(ob_get_clean()); ?>

        </table>
    </ui-table-scroll-area>

    

    </div>
<?php echo ltrim(ob_get_clean()); ?>

    <!-- Pagination -->
    <div>
        <?php echo e($partners->links()); ?>

    </div>
</div>
<?php /**PATH C:\laragon\www\bossed-landig-page\resources\views/livewire/admin/partner-index.blade.php ENDPATH**/ ?>