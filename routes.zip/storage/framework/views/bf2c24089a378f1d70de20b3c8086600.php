<?php # [BlazeFolded]:{flux::heading}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::subheading}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/subheading.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::badge}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/badge/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.column}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/column.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.column}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/column.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.column}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/column.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.column}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/column.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.column}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/column.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.column}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/column.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.column}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/column.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.columns}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/columns.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.cell}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/cell.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.cell}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/cell.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.cell}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/cell.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.cell}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/cell.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.cell}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/cell.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::badge}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/badge/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::badge}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/badge/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::badge}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/badge/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.cell}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/cell.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.cell}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/cell.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.row}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/row.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.cell}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/cell.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.row}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/row.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table.rows}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/rows.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::table}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/table/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::heading}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/heading.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::subheading}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/subheading.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::label}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/label.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::select.option}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/select/option/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::select}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/select/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::field}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/field.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::label}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/label.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::field}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/field.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::label}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/label.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::field}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/field.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::label}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/label.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::field}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/field.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::label}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/label.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::select.option}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/select/option/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::select.option}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/select/option/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::select.option}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/select/option/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::select}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/select/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::field}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/field.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::label}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/label.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::field}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/field.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1786017876} ?>
<?php # [BlazeFolded]:{flux::button}:{C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php}:{1786017876} ?>
<div class="md:p-6 space-y-6">
    <!-- Header Section -->
    <div class="flex items-center justify-between">
        <div>
            <?php ob_start(); ?><h1 class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-2xl [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>Moderasi Ulasan Produk<?php echo trim(ob_get_clean()); ?></h1>

        <!--[if ENDBLOCK]><![endif]--><?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><div class="text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70" data-flux-subheading>
    <?php ob_start(); ?>
                Tinjau ulasan dan rating produk dari pengunjung sebelum ditayangkan di halaman detail produk.
            <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
        </div>

        <?php ob_start(); ?><button type="button" class="relative items-center font-medium justify-center gap-2 whitespace-nowrap disabled:opacity-75 dark:disabled:opacity-75 disabled:cursor-default disabled:pointer-events-none justify-center h-10 text-sm rounded-lg ps-3 pe-4 inline-flex  bg-[var(--color-accent)] hover:bg-[color-mix(in_oklab,_var(--color-accent),_transparent_10%)] text-[var(--color-accent-foreground)] border border-black/10 dark:border-0 shadow-[inset_0px_1px_--theme(--color-white/.2)] [[data-flux-button-group]_&amp;]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-[1px] dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-s-[1px] [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[color-mix(in_srgb,var(--color-accent-foreground),transparent_85%)] *:transition-opacity [&amp;[data-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-flux-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-loading]&gt;[data-flux-loading-indicator]]:opacity-100 [&amp;[data-flux-loading]&gt;[data-flux-loading-indicator]]:opacity-100 data-loading:pointer-events-none data-flux-loading:pointer-events-none" data-flux-button="data-flux-button" data-flux-group-target="data-flux-group-target" wire:target="create" wire:loading.attr="data-flux-loading" wire:click="create">
        <div class="absolute inset-0 flex items-center justify-center opacity-0" data-flux-loading-indicator>
                <svg class="shrink-0 [:where(&amp;)]:size-4 animate-spin" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true" data-slot="icon">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
</svg>
                    </div>
        
                    <svg class="shrink-0 [:where(&amp;)]:size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path d="M8.75 3.75a.75.75 0 0 0-1.5 0v3.5h-3.5a.75.75 0 0 0 0 1.5h3.5v3.5a.75.75 0 0 0 1.5 0v-3.5h3.5a.75.75 0 0 0 0-1.5h-3.5v-3.5Z"/>
</svg>

                
                    
            
            <span><?php ob_start(); ?>
            Tambah Ulasan
        <?php echo trim(ob_get_clean()); ?></span>
    </button>
<?php echo ltrim(ob_get_clean()); ?>
    </div>

    <!-- Alert / Flash Message -->
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session()->has('message')): ?>
        <?php ob_start(); ?><div data-flux-badge="data-flux-badge" class="inline-flex items-center font-medium whitespace-nowrap  [print-color-adjust:exact] text-sm py-1.5 **:data-flux-badge-icon:me-2 rounded-md px-2 text-green-800 [&amp;_button]:text-green-800! dark:text-green-200 dark:[&amp;_button]:text-green-200! bg-green-400/20 dark:bg-green-400/40 [&amp;:is(button)]:hover:bg-green-400/30 dark:[button]:hover:bg-green-400/50 w-full justify-start py-3 px-4">
        <?php ob_start(); ?>
            <?php echo e(session('message')); ?>

        <?php echo trim(ob_get_clean()); ?>

    </div>
<?php echo ltrim(ob_get_clean()); ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <!-- Filter & Search Section -->
    <div
        class="flex flex-col md:flex-row justify-between items-center gap-4 bg-white dark:bg-zinc-800 p-4 rounded-xl border border-zinc-200 dark:border-zinc-700 shadow-sm">
        <div class="w-full md:w-1/3">
            <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/input/index.blade.php', $__blaze->compiledPath.'/7d4f1be85db8dbf791d2ec038e21b28f.php'); ?>
<?php $__blaze->pushData(['wire:model.live.debounce.300ms' => 'search','type' => 'search','placeholder' => 'Cari pengirim, email, produk, atau komentar...','icon' => 'magnifying-glass']); ?>
<?php _7d4f1be85db8dbf791d2ec038e21b28f($__blaze, ['wire:model.live.debounce.300ms' => 'search','type' => 'search','placeholder' => 'Cari pengirim, email, produk, atau komentar...','icon' => 'magnifying-glass'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
        </div>

        <!-- Filter Status Buttons -->
        <div class="flex flex-wrap gap-2 w-full md:w-auto">
            <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php', $__blaze->compiledPath.'/44befdf667a8bbc607e3c8a333ca98af.php'); ?>
<?php if (isset($__slots44befdf667a8bbc607e3c8a333ca98af)) { $__slotsStack44befdf667a8bbc607e3c8a333ca98af[] = $__slots44befdf667a8bbc607e3c8a333ca98af; } ?>
<?php if (isset($__attrs44befdf667a8bbc607e3c8a333ca98af)) { $__attrsStack44befdf667a8bbc607e3c8a333ca98af[] = $__attrs44befdf667a8bbc607e3c8a333ca98af; } ?>
<?php $__attrs44befdf667a8bbc607e3c8a333ca98af = ['wire:click' => '$set(\'filterStatus\', \'all\')','variant' => e($filterStatus === 'all' ? 'primary' : 'subtle'),'size' => 'sm']; ?>
<?php $__slots44befdf667a8bbc607e3c8a333ca98af = []; ?>
<?php $__blaze->pushData($__attrs44befdf667a8bbc607e3c8a333ca98af); ?>
<?php ob_start(); ?>
                Semua
            <?php $__slots44befdf667a8bbc607e3c8a333ca98af['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots44befdf667a8bbc607e3c8a333ca98af); ?>
<?php _44befdf667a8bbc607e3c8a333ca98af($__blaze, $__attrs44befdf667a8bbc607e3c8a333ca98af, $__slots44befdf667a8bbc607e3c8a333ca98af, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack44befdf667a8bbc607e3c8a333ca98af)) { $__slots44befdf667a8bbc607e3c8a333ca98af = array_pop($__slotsStack44befdf667a8bbc607e3c8a333ca98af); } ?>
<?php if (! empty($__attrsStack44befdf667a8bbc607e3c8a333ca98af)) { $__attrs44befdf667a8bbc607e3c8a333ca98af = array_pop($__attrsStack44befdf667a8bbc607e3c8a333ca98af); } ?>
<?php $__blaze->popData(); ?>

            <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php', $__blaze->compiledPath.'/44befdf667a8bbc607e3c8a333ca98af.php'); ?>
<?php if (isset($__slots44befdf667a8bbc607e3c8a333ca98af)) { $__slotsStack44befdf667a8bbc607e3c8a333ca98af[] = $__slots44befdf667a8bbc607e3c8a333ca98af; } ?>
<?php if (isset($__attrs44befdf667a8bbc607e3c8a333ca98af)) { $__attrsStack44befdf667a8bbc607e3c8a333ca98af[] = $__attrs44befdf667a8bbc607e3c8a333ca98af; } ?>
<?php $__attrs44befdf667a8bbc607e3c8a333ca98af = ['wire:click' => '$set(\'filterStatus\', \'pending\')','variant' => e($filterStatus === 'pending' ? 'filled' : 'subtle'),'color' => 'yellow','size' => 'sm']; ?>
<?php $__slots44befdf667a8bbc607e3c8a333ca98af = []; ?>
<?php $__blaze->pushData($__attrs44befdf667a8bbc607e3c8a333ca98af); ?>
<?php ob_start(); ?>
                Perlu Moderasi (Pending)
            <?php $__slots44befdf667a8bbc607e3c8a333ca98af['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots44befdf667a8bbc607e3c8a333ca98af); ?>
<?php _44befdf667a8bbc607e3c8a333ca98af($__blaze, $__attrs44befdf667a8bbc607e3c8a333ca98af, $__slots44befdf667a8bbc607e3c8a333ca98af, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack44befdf667a8bbc607e3c8a333ca98af)) { $__slots44befdf667a8bbc607e3c8a333ca98af = array_pop($__slotsStack44befdf667a8bbc607e3c8a333ca98af); } ?>
<?php if (! empty($__attrsStack44befdf667a8bbc607e3c8a333ca98af)) { $__attrs44befdf667a8bbc607e3c8a333ca98af = array_pop($__attrsStack44befdf667a8bbc607e3c8a333ca98af); } ?>
<?php $__blaze->popData(); ?>

            <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php', $__blaze->compiledPath.'/44befdf667a8bbc607e3c8a333ca98af.php'); ?>
<?php if (isset($__slots44befdf667a8bbc607e3c8a333ca98af)) { $__slotsStack44befdf667a8bbc607e3c8a333ca98af[] = $__slots44befdf667a8bbc607e3c8a333ca98af; } ?>
<?php if (isset($__attrs44befdf667a8bbc607e3c8a333ca98af)) { $__attrsStack44befdf667a8bbc607e3c8a333ca98af[] = $__attrs44befdf667a8bbc607e3c8a333ca98af; } ?>
<?php $__attrs44befdf667a8bbc607e3c8a333ca98af = ['wire:click' => '$set(\'filterStatus\', \'approved\')','variant' => e($filterStatus === 'approved' ? 'filled' : 'subtle'),'color' => 'green','size' => 'sm']; ?>
<?php $__slots44befdf667a8bbc607e3c8a333ca98af = []; ?>
<?php $__blaze->pushData($__attrs44befdf667a8bbc607e3c8a333ca98af); ?>
<?php ob_start(); ?>
                Disetujui
            <?php $__slots44befdf667a8bbc607e3c8a333ca98af['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots44befdf667a8bbc607e3c8a333ca98af); ?>
<?php _44befdf667a8bbc607e3c8a333ca98af($__blaze, $__attrs44befdf667a8bbc607e3c8a333ca98af, $__slots44befdf667a8bbc607e3c8a333ca98af, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack44befdf667a8bbc607e3c8a333ca98af)) { $__slots44befdf667a8bbc607e3c8a333ca98af = array_pop($__slotsStack44befdf667a8bbc607e3c8a333ca98af); } ?>
<?php if (! empty($__attrsStack44befdf667a8bbc607e3c8a333ca98af)) { $__attrs44befdf667a8bbc607e3c8a333ca98af = array_pop($__attrsStack44befdf667a8bbc607e3c8a333ca98af); } ?>
<?php $__blaze->popData(); ?>

            <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php', $__blaze->compiledPath.'/44befdf667a8bbc607e3c8a333ca98af.php'); ?>
<?php if (isset($__slots44befdf667a8bbc607e3c8a333ca98af)) { $__slotsStack44befdf667a8bbc607e3c8a333ca98af[] = $__slots44befdf667a8bbc607e3c8a333ca98af; } ?>
<?php if (isset($__attrs44befdf667a8bbc607e3c8a333ca98af)) { $__attrsStack44befdf667a8bbc607e3c8a333ca98af[] = $__attrs44befdf667a8bbc607e3c8a333ca98af; } ?>
<?php $__attrs44befdf667a8bbc607e3c8a333ca98af = ['wire:click' => '$set(\'filterStatus\', \'rejected\')','variant' => e($filterStatus === 'rejected' ? 'filled' : 'subtle'),'color' => 'red','size' => 'sm']; ?>
<?php $__slots44befdf667a8bbc607e3c8a333ca98af = []; ?>
<?php $__blaze->pushData($__attrs44befdf667a8bbc607e3c8a333ca98af); ?>
<?php ob_start(); ?>
                Ditolak
            <?php $__slots44befdf667a8bbc607e3c8a333ca98af['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots44befdf667a8bbc607e3c8a333ca98af); ?>
<?php _44befdf667a8bbc607e3c8a333ca98af($__blaze, $__attrs44befdf667a8bbc607e3c8a333ca98af, $__slots44befdf667a8bbc607e3c8a333ca98af, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack44befdf667a8bbc607e3c8a333ca98af)) { $__slots44befdf667a8bbc607e3c8a333ca98af = array_pop($__slotsStack44befdf667a8bbc607e3c8a333ca98af); } ?>
<?php if (! empty($__attrsStack44befdf667a8bbc607e3c8a333ca98af)) { $__attrs44befdf667a8bbc607e3c8a333ca98af = array_pop($__attrsStack44befdf667a8bbc607e3c8a333ca98af); } ?>
<?php $__blaze->popData(); ?>
        </div>
    </div>

    <!-- Data Table -->
    <?php ob_start(); ?><div class="flex flex-col ">
    

    <ui-table-scroll-area class="overflow-auto">
        <table class="[:where(&amp;)]:min-w-full table-fixed border-separate border-spacing-0 isolate text-zinc-800 whitespace-nowrap [&amp;_dialog]:whitespace-normal [&amp;_[popover]]:whitespace-normal" data-flux-table>
            <?php ob_start(); ?>
        <?php ob_start(); ?><thead class="" data-flux-columns>
    <tr >
        <?php ob_start(); ?>
            <?php ob_start(); ?><th class="py-3 px-3 first:ps-0 last:pe-0 text-start text-sm font-medium text-zinc-800 dark:text-white border-b border-zinc-800/10 dark:border-white/20    **:data-flux-table-sortable:last:me-0" data-flux-column>
            <div class="flex in-[.group\/center-align]:justify-center in-[.group\/end-align]:justify-end"><?php ob_start(); ?>Pengirim & Email<?php echo trim(ob_get_clean()); ?></div>
    </th>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><th class="py-3 px-3 first:ps-0 last:pe-0 text-start text-sm font-medium text-zinc-800 dark:text-white border-b border-zinc-800/10 dark:border-white/20    **:data-flux-table-sortable:last:me-0" data-flux-column>
            <div class="flex in-[.group\/center-align]:justify-center in-[.group\/end-align]:justify-end"><?php ob_start(); ?>Produk<?php echo trim(ob_get_clean()); ?></div>
    </th>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><th class="py-3 px-3 first:ps-0 last:pe-0 text-start text-sm font-medium text-zinc-800 dark:text-white border-b border-zinc-800/10 dark:border-white/20    **:data-flux-table-sortable:last:me-0" data-flux-column>
            <div class="flex in-[.group\/center-align]:justify-center in-[.group\/end-align]:justify-end"><?php ob_start(); ?>Rating<?php echo trim(ob_get_clean()); ?></div>
    </th>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><th class="py-3 px-3 first:ps-0 last:pe-0 text-start text-sm font-medium text-zinc-800 dark:text-white border-b border-zinc-800/10 dark:border-white/20    **:data-flux-table-sortable:last:me-0" data-flux-column>
            <div class="flex in-[.group\/center-align]:justify-center in-[.group\/end-align]:justify-end"><?php ob_start(); ?>Ulasan<?php echo trim(ob_get_clean()); ?></div>
    </th>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><th class="py-3 px-3 first:ps-0 last:pe-0 text-start text-sm font-medium text-zinc-800 dark:text-white border-b border-zinc-800/10 dark:border-white/20    **:data-flux-table-sortable:last:me-0" data-flux-column>
            <div class="flex in-[.group\/center-align]:justify-center in-[.group\/end-align]:justify-end"><?php ob_start(); ?>Tanggal<?php echo trim(ob_get_clean()); ?></div>
    </th>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><th class="py-3 px-3 first:ps-0 last:pe-0 text-start text-sm font-medium text-zinc-800 dark:text-white border-b border-zinc-800/10 dark:border-white/20    **:data-flux-table-sortable:last:me-0" data-flux-column>
            <div class="flex in-[.group\/center-align]:justify-center in-[.group\/end-align]:justify-end"><?php ob_start(); ?>Status<?php echo trim(ob_get_clean()); ?></div>
    </th>
<?php echo ltrim(ob_get_clean()); ?>
            <?php ob_start(); ?><th class="py-3 px-3 first:ps-0 last:pe-0 text-start text-sm font-medium text-zinc-800 dark:text-white border-b border-zinc-800/10 dark:border-white/20    **:data-flux-table-sortable:last:me-0 text-right" data-flux-column>
            <div class="flex in-[.group\/center-align]:justify-center in-[.group\/end-align]:justify-end"><?php ob_start(); ?>Aksi Moderasi<?php echo trim(ob_get_clean()); ?></div>
    </th>
<?php echo ltrim(ob_get_clean()); ?>
        <?php echo trim(ob_get_clean()); ?>

    </tr>
</thead>
<?php echo ltrim(ob_get_clean()); ?>

        <?php ob_start(); ?><tbody  data-flux-rows>
    <?php ob_start(); ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php ob_start(); ?><tr  <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'table-'.e($item->id).''; ?>wire:key="table-<?php echo e($item->id); ?>"  class="" data-flux-row>
    <?php ob_start(); ?>
                    <!-- Column: Pengirim & Email -->
                    <?php ob_start(); ?><td class="[:where(&amp;)]:py-3 [:where(&amp;)]:px-3 first:ps-0 last:pe-0 text-sm  text-zinc-500 dark:text-zinc-300  not-in-[tr:first-child]:border-t border-zinc-800/10 dark:border-white/20" data-flux-cell>
    <?php ob_start(); ?>
                        <div class="flex items-center gap-3">
                            <?php $blaze_memoized_key = \Livewire\Blaze\Memoizer\Memo::key("flux::avatar", ['name' => e($item->name), 'size' => 'sm']); ?><?php if ($blaze_memoized_key !== null && \Livewire\Blaze\Memoizer\Memo::has($blaze_memoized_key)) : ?><?php echo \Livewire\Blaze\Memoizer\Memo::get($blaze_memoized_key); ?><?php else : ?><?php ob_start(); ?><?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/avatar/index.blade.php', $__blaze->compiledPath.'/df376c1cd0aff66e8a931535ec3acf29.php'); ?>
<?php $__blaze->pushData(['name' => e($item->name),'size' => 'sm']); ?>
<?php _df376c1cd0aff66e8a931535ec3acf29($__blaze, ['name' => e($item->name),'size' => 'sm'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?><?php $blaze_memoized_html = ob_get_clean(); ?><?php if ($blaze_memoized_key !== null) { \Livewire\Blaze\Memoizer\Memo::put($blaze_memoized_key, $blaze_memoized_html); } ?><?php echo $blaze_memoized_html; ?><?php endif; ?>
                            <div>
                                <div class="font-medium text-zinc-800 dark:text-zinc-200 text-sm">
                                    <?php echo e($item->name); ?>

                                </div>
                                <div class="text-xs text-zinc-400 dark:text-zinc-500">
                                    <?php echo e($item->email ?? 'Tidak ada email'); ?>

                                </div>
                            </div>
                        </div>
                    <?php echo trim(ob_get_clean()); ?>

</td>
<?php echo ltrim(ob_get_clean()); ?>

                    <!-- Column: Produk -->
                    <?php ob_start(); ?><td class="[:where(&amp;)]:py-3 [:where(&amp;)]:px-3 first:ps-0 last:pe-0 text-sm  text-zinc-500 dark:text-zinc-300  not-in-[tr:first-child]:border-t border-zinc-800/10 dark:border-white/20 max-w-[180px]" data-flux-cell>
    <?php ob_start(); ?>
                        <div class="font-medium text-xs text-zinc-700 dark:text-zinc-300 truncate"
                            title="<?php echo e($item->product->name ?? 'Produk Dihapus'); ?>">
                            <?php echo e($item->product->name ?? 'Produk Dihapus'); ?>

                        </div>
                    <?php echo trim(ob_get_clean()); ?>

</td>
<?php echo ltrim(ob_get_clean()); ?>

                    <!-- Column: Rating Stars -->
                    <?php ob_start(); ?><td class="[:where(&amp;)]:py-3 [:where(&amp;)]:px-3 first:ps-0 last:pe-0 text-sm  text-zinc-500 dark:text-zinc-300  not-in-[tr:first-child]:border-t border-zinc-800/10 dark:border-white/20" data-flux-cell>
    <?php ob_start(); ?>
                        <div class="flex text-amber-400 text-sm">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php for($i = 1; $i <= 5; $i++): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <span><?php echo e($i <= $item->rating ? '★' : '☆'); ?></span>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </div>
                    <?php echo trim(ob_get_clean()); ?>

</td>
<?php echo ltrim(ob_get_clean()); ?>

                    <!-- Column: Comment -->
                    <?php ob_start(); ?><td class="[:where(&amp;)]:py-3 [:where(&amp;)]:px-3 first:ps-0 last:pe-0 text-sm  text-zinc-500 dark:text-zinc-300  not-in-[tr:first-child]:border-t border-zinc-800/10 dark:border-white/20 max-w-md" data-flux-cell>
    <?php ob_start(); ?>
                        <p
                            class="italic text-xs bg-zinc-50 dark:bg-zinc-900/50 p-2.5 rounded-lg border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300">
                            "<?php echo e($item->comment); ?>"
                        </p>
                    <?php echo trim(ob_get_clean()); ?>

</td>
<?php echo ltrim(ob_get_clean()); ?>

                    <!-- Column: Tanggal -->
                    <?php ob_start(); ?><td class="[:where(&amp;)]:py-3 [:where(&amp;)]:px-3 first:ps-0 last:pe-0 text-sm  text-zinc-500 dark:text-zinc-300  not-in-[tr:first-child]:border-t border-zinc-800/10 dark:border-white/20 text-xs text-zinc-500 dark:text-zinc-400 whitespace-nowrap" data-flux-cell>
    <?php ob_start(); ?>
                        <?php echo e($item->created_at->format('d M Y, H:i')); ?>

                    <?php echo trim(ob_get_clean()); ?>

</td>
<?php echo ltrim(ob_get_clean()); ?>

                    <!-- Column: Status Badge -->
                    <?php ob_start(); ?><td class="[:where(&amp;)]:py-3 [:where(&amp;)]:px-3 first:ps-0 last:pe-0 text-sm  text-zinc-500 dark:text-zinc-300  not-in-[tr:first-child]:border-t border-zinc-800/10 dark:border-white/20 whitespace-nowrap" data-flux-cell>
    <?php ob_start(); ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->status === 'approved'): ?>
                            <?php ob_start(); ?><div data-flux-badge="data-flux-badge" class="inline-flex items-center font-medium whitespace-nowrap  [print-color-adjust:exact] text-xs py-1 **:data-flux-badge-icon:me-1 rounded-md px-2 text-green-800 [&amp;_button]:text-green-800! dark:text-green-200 dark:[&amp;_button]:text-green-200! bg-green-400/20 dark:bg-green-400/40 [&amp;:is(button)]:hover:bg-green-400/30 dark:[button]:hover:bg-green-400/50">
        <?php ob_start(); ?>Disetujui<?php echo trim(ob_get_clean()); ?>

    </div>
<?php echo ltrim(ob_get_clean()); ?>
                        <?php elseif($item->status === 'rejected'): ?>
                            <?php ob_start(); ?><div data-flux-badge="data-flux-badge" class="inline-flex items-center font-medium whitespace-nowrap  [print-color-adjust:exact] text-xs py-1 **:data-flux-badge-icon:me-1 rounded-md px-2 text-red-700 [&amp;_button]:text-red-700! dark:text-red-200 dark:[&amp;_button]:text-red-200! bg-red-400/20 dark:bg-red-400/40 [&amp;:is(button)]:hover:bg-red-400/30 dark:[button]:hover:bg-red-400/50">
        <?php ob_start(); ?>Ditolak<?php echo trim(ob_get_clean()); ?>

    </div>
<?php echo ltrim(ob_get_clean()); ?>
                        <?php else: ?>
                            <?php ob_start(); ?><div data-flux-badge="data-flux-badge" class="inline-flex items-center font-medium whitespace-nowrap  [print-color-adjust:exact] text-xs py-1 **:data-flux-badge-icon:me-1 rounded-md px-2 text-yellow-800 [&amp;_button]:text-yellow-800! dark:text-yellow-200 dark:[&amp;_button]:text-yellow-200! bg-yellow-400/25 dark:bg-yellow-400/40 [&amp;:is(button)]:hover:bg-yellow-400/40 dark:[button]:hover:bg-yellow-400/50">
        <?php ob_start(); ?>Pending<?php echo trim(ob_get_clean()); ?>

    </div>
<?php echo ltrim(ob_get_clean()); ?>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php echo trim(ob_get_clean()); ?>

</td>
<?php echo ltrim(ob_get_clean()); ?>

                    <!-- Column: Action Buttons -->
                    <?php ob_start(); ?><td class="[:where(&amp;)]:py-3 [:where(&amp;)]:px-3 first:ps-0 last:pe-0 text-sm  text-zinc-500 dark:text-zinc-300  not-in-[tr:first-child]:border-t border-zinc-800/10 dark:border-white/20 text-right whitespace-nowrap" data-flux-cell>
    <?php ob_start(); ?>
                        <div class="flex justify-end items-center gap-1.5">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->status !== 'approved'): ?>
                                <?php ob_start(); ?><button type="button" class="relative items-center font-medium justify-center gap-2 whitespace-nowrap disabled:opacity-75 dark:disabled:opacity-75 disabled:cursor-default disabled:pointer-events-none justify-center h-8 text-sm rounded-md px-3 inline-flex  bg-zinc-800/5 hover:bg-zinc-800/10 dark:bg-white/10 dark:hover:bg-white/20 text-zinc-800 dark:text-white   [[data-flux-button-group]_&amp;]:border-e [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 [[data-flux-button-group]_&amp;]:border-zinc-200/80 dark:[[data-flux-button-group]_&amp;]:border-zinc-900/50 *:transition-opacity [&amp;[data-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-flux-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-loading]&gt;[data-flux-loading-indicator]]:opacity-100 [&amp;[data-flux-loading]&gt;[data-flux-loading-indicator]]:opacity-100 data-loading:pointer-events-none data-flux-loading:pointer-events-none" data-flux-button="data-flux-button" data-flux-group-target="data-flux-group-target" wire:target="updateStatus(<?php echo e($item->id); ?>, 'approved')" wire:loading.attr="data-flux-loading" wire:click="updateStatus(<?php echo e($item->id); ?>, 'approved')">
        <div class="absolute inset-0 flex items-center justify-center opacity-0" data-flux-loading-indicator>
                <svg class="shrink-0 [:where(&amp;)]:size-4 animate-spin" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true" data-slot="icon">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
</svg>
                    </div>
        
                    <svg class="shrink-0 [:where(&amp;)]:size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path fill-rule="evenodd" d="M12.416 3.376a.75.75 0 0 1 .208 1.04l-5 7.5a.75.75 0 0 1-1.154.114l-3-3a.75.75 0 0 1 1.06-1.06l2.353 2.353 4.493-6.74a.75.75 0 0 1 1.04-.207Z" clip-rule="evenodd"/>
</svg>

                
                    
            
            <span><?php ob_start(); ?>
                                    Setujui
                                <?php echo trim(ob_get_clean()); ?></span>
    </button>
<?php echo ltrim(ob_get_clean()); ?>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->status !== 'rejected'): ?>
                                <?php ob_start(); ?><button type="button" class="relative items-center font-medium justify-center gap-2 whitespace-nowrap disabled:opacity-75 dark:disabled:opacity-75 disabled:cursor-default disabled:pointer-events-none justify-center h-8 text-sm rounded-md px-3 inline-flex  bg-zinc-800/5 hover:bg-zinc-800/10 dark:bg-white/10 dark:hover:bg-white/20 text-zinc-800 dark:text-white   [[data-flux-button-group]_&amp;]:border-e [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 [[data-flux-button-group]_&amp;]:border-zinc-200/80 dark:[[data-flux-button-group]_&amp;]:border-zinc-900/50 *:transition-opacity [&amp;[data-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-flux-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-loading]&gt;[data-flux-loading-indicator]]:opacity-100 [&amp;[data-flux-loading]&gt;[data-flux-loading-indicator]]:opacity-100 data-loading:pointer-events-none data-flux-loading:pointer-events-none" data-flux-button="data-flux-button" data-flux-group-target="data-flux-group-target" wire:target="updateStatus(<?php echo e($item->id); ?>, 'rejected')" wire:loading.attr="data-flux-loading" wire:click="updateStatus(<?php echo e($item->id); ?>, 'rejected')">
        <div class="absolute inset-0 flex items-center justify-center opacity-0" data-flux-loading-indicator>
                <svg class="shrink-0 [:where(&amp;)]:size-4 animate-spin" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true" data-slot="icon">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
</svg>
                    </div>
        
                    <svg class="shrink-0 [:where(&amp;)]:size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path d="M5.28 4.22a.75.75 0 0 0-1.06 1.06L6.94 8l-2.72 2.72a.75.75 0 1 0 1.06 1.06L8 9.06l2.72 2.72a.75.75 0 1 0 1.06-1.06L9.06 8l2.72-2.72a.75.75 0 0 0-1.06-1.06L8 6.94 5.28 4.22Z"/>
</svg>

                
                    
            
            <span><?php ob_start(); ?>
                                    Tolak
                                <?php echo trim(ob_get_clean()); ?></span>
    </button>
<?php echo ltrim(ob_get_clean()); ?>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            <?php ob_start(); ?><button type="button" class="relative items-center font-medium justify-center gap-2 whitespace-nowrap disabled:opacity-75 dark:disabled:opacity-75 disabled:cursor-default disabled:pointer-events-none justify-center h-8 text-sm rounded-md px-3 inline-flex  bg-red-500 hover:bg-red-600 dark:bg-red-600 dark:hover:bg-red-500 text-white  shadow-[inset_0px_1px_var(--color-red-500),inset_0px_2px_--theme(--color-white/.15)] dark:shadow-none [[data-flux-button-group]_&amp;]:border-e [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 [[data-flux-button-group]_&amp;]:border-red-600 dark:[[data-flux-button-group]_&amp;]:border-red-900/25 *:transition-opacity [&amp;[data-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-flux-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-loading]&gt;[data-flux-loading-indicator]]:opacity-100 [&amp;[data-flux-loading]&gt;[data-flux-loading-indicator]]:opacity-100 data-loading:pointer-events-none data-flux-loading:pointer-events-none" data-flux-button="data-flux-button" data-flux-group-target="data-flux-group-target" wire:target="delete(<?php echo e($item->id); ?>)" wire:loading.attr="data-flux-loading" wire:click="delete(<?php echo e($item->id); ?>)" wire:confirm="Yakin ingin menghapus ulasan ini secara permanen?">
        <div class="absolute inset-0 flex items-center justify-center opacity-0" data-flux-loading-indicator>
                <svg class="shrink-0 [:where(&amp;)]:size-4 animate-spin" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true" data-slot="icon">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
</svg>
                    </div>
        
                    <svg class="shrink-0 [:where(&amp;)]:size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path fill-rule="evenodd" d="M5 3.25V4H2.75a.75.75 0 0 0 0 1.5h.3l.815 8.15A1.5 1.5 0 0 0 5.357 15h5.285a1.5 1.5 0 0 0 1.493-1.35l.815-8.15h.3a.75.75 0 0 0 0-1.5H11v-.75A2.25 2.25 0 0 0 8.75 1h-1.5A2.25 2.25 0 0 0 5 3.25Zm2.25-.75a.75.75 0 0 0-.75.75V4h3v-.75a.75.75 0 0 0-.75-.75h-1.5ZM6.05 6a.75.75 0 0 1 .787.713l.275 5.5a.75.75 0 0 1-1.498.075l-.275-5.5A.75.75 0 0 1 6.05 6Zm3.9 0a.75.75 0 0 1 .712.787l-.275 5.5a.75.75 0 0 1-1.498-.075l.275-5.5a.75.75 0 0 1 .786-.711Z" clip-rule="evenodd"/>
</svg>

                
                    
            
            <span><?php ob_start(); ?>
                                Hapus
                            <?php echo trim(ob_get_clean()); ?></span>
    </button>
<?php echo ltrim(ob_get_clean()); ?>
                            <?php ob_start(); ?><button type="button" class="relative items-center font-medium justify-center gap-2 whitespace-nowrap disabled:opacity-75 dark:disabled:opacity-75 disabled:cursor-default disabled:pointer-events-none justify-center h-8 text-sm rounded-md px-3 inline-flex  bg-transparent hover:bg-zinc-800/5 dark:hover:bg-white/15 text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white    *:transition-opacity [&amp;[data-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-flux-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-loading]&gt;[data-flux-loading-indicator]]:opacity-100 [&amp;[data-flux-loading]&gt;[data-flux-loading-indicator]]:opacity-100 data-loading:pointer-events-none data-flux-loading:pointer-events-none" data-flux-button="data-flux-button" wire:target="edit(<?php echo e($item->id); ?>)" wire:loading.attr="data-flux-loading" wire:click="edit(<?php echo e($item->id); ?>)">
        <div class="absolute inset-0 flex items-center justify-center opacity-0" data-flux-loading-indicator>
                <svg class="shrink-0 [:where(&amp;)]:size-4 animate-spin" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true" data-slot="icon">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
</svg>
                    </div>
        
                    <svg class="shrink-0 [:where(&amp;)]:size-4" data-flux-icon xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true" data-slot="icon">
  <path fill-rule="evenodd" d="M11.013 2.513a1.75 1.75 0 0 1 2.475 2.474L6.226 12.25a2.751 2.751 0 0 1-.892.596l-2.047.848a.75.75 0 0 1-.98-.98l.848-2.047a2.75 2.75 0 0 1 .596-.892l7.262-7.261Z" clip-rule="evenodd"/>
</svg>

                
                    
            
            <span><?php ob_start(); ?>
                                Edit
                            <?php echo trim(ob_get_clean()); ?></span>
    </button>
<?php echo ltrim(ob_get_clean()); ?>
                        </div>
                    <?php echo trim(ob_get_clean()); ?>

</td>
<?php echo ltrim(ob_get_clean()); ?>
                <?php echo trim(ob_get_clean()); ?>

</tr>
<?php echo ltrim(ob_get_clean()); ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <?php ob_start(); ?><tr  class="" data-flux-row>
    <?php ob_start(); ?>
                    <?php ob_start(); ?><td class="[:where(&amp;)]:py-3 [:where(&amp;)]:px-3 first:ps-0 last:pe-0 text-sm  text-zinc-500 dark:text-zinc-300  not-in-[tr:first-child]:border-t border-zinc-800/10 dark:border-white/20 text-center py-6 text-zinc-500 dark:text-zinc-400" colspan="7" data-flux-cell>
    <?php ob_start(); ?>
                        Tidak ada data ulasan produk.
                    <?php echo trim(ob_get_clean()); ?>

</td>
<?php echo ltrim(ob_get_clean()); ?>
                <?php echo trim(ob_get_clean()); ?>

</tr>
<?php echo ltrim(ob_get_clean()); ?>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php echo trim(ob_get_clean()); ?>

</tbody>
<?php echo ltrim(ob_get_clean()); ?>
    <?php echo trim(ob_get_clean()); ?>

        </table>
    </ui-table-scroll-area>

    

    </div>
<?php echo ltrim(ob_get_clean()); ?>

    <!-- Pagination -->
    <div>
        <?php echo e($reviews->links()); ?>

    </div>

    <!-- Modal Tambah/Edit Ulasan -->
    <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/modal/index.blade.php', $__blaze->compiledPath.'/44e4610bfcfca018bf54460c1f0baace.php'); ?>
<?php if (isset($__slots44e4610bfcfca018bf54460c1f0baace)) { $__slotsStack44e4610bfcfca018bf54460c1f0baace[] = $__slots44e4610bfcfca018bf54460c1f0baace; } ?>
<?php if (isset($__attrs44e4610bfcfca018bf54460c1f0baace)) { $__attrsStack44e4610bfcfca018bf54460c1f0baace[] = $__attrs44e4610bfcfca018bf54460c1f0baace; } ?>
<?php $__attrs44e4610bfcfca018bf54460c1f0baace = ['wire:model.self' => 'showModal','class' => 'max-w-2xl w-full']; ?>
<?php $__slots44e4610bfcfca018bf54460c1f0baace = []; ?>
<?php $__blaze->pushData($__attrs44e4610bfcfca018bf54460c1f0baace); ?>
<?php ob_start(); ?>
        <form wire:submit="save" class="space-y-5">
            <div>
                <?php ob_start(); ?><div class="font-medium [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white text-base [&amp;:has(+[data-flux-subheading])]:mb-2 [[data-flux-subheading]+&amp;]:mt-2" data-flux-heading><?php ob_start(); ?>
                    <?php echo e($editingId ? 'Edit Ulasan Produk' : 'Tambah Ulasan Baru'); ?>

                <?php echo trim(ob_get_clean()); ?></div>
<?php echo ltrim(ob_get_clean()); ?>
                <?php ob_start(); ?><div class="text-sm [:where(&amp;)]:text-zinc-500 [:where(&amp;)]:dark:text-white/70" data-flux-subheading>
    <?php ob_start(); ?>
                    <?php echo e($editingId ? 'Perbarui data ulasan ini.' : 'Input manual ulasan dari admin.'); ?>

                <?php echo trim(ob_get_clean()); ?>

</div>
<?php echo ltrim(ob_get_clean()); ?>
            </div>

            <!-- Produk (Full Width) -->
            <?php ob_start(); ?><ui-field class="min-w-0 [&amp;:not(:has([data-flux-field])):has([data-flux-control][disabled])&gt;[data-flux-label]]:opacity-50 [&amp;:has(&gt;[data-flux-radio-group][disabled])&gt;[data-flux-label]]:opacity-50 [&amp;:has(&gt;[data-flux-checkbox-group][disabled])&gt;[data-flux-label]]:opacity-50 block *:data-flux-label:mb-3 [&amp;&gt;[data-flux-label]:has(+[data-flux-description])]:mb-2 [&amp;&gt;[data-flux-label]+[data-flux-description]]:mt-0 [&amp;&gt;[data-flux-label]+[data-flux-description]]:mb-3 [&amp;&gt;[data-flux-description]:first-child:has(+*)]:mb-3 [&amp;&gt;*:not([data-flux-label])+[data-flux-description]]:mt-3" data-flux-field>
    <?php ob_start(); ?>
                <?php ob_start(); ?><ui-label class="inline-flex items-center text-sm font-medium  [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white [&amp;:has([data-flux-label-trailing])]:flex" data-flux-label>
    <?php ob_start(); ?>Produk <span class="text-red-500">*</span><?php echo trim(ob_get_clean()); ?>


    
    
    </ui-label>
<?php echo ltrim(ob_get_clean()); ?>
                <?php ob_start(); ?><?php $__blaze->pushData(['wire:model' => 'product_id', 'placeholder' => 'Pilih produk...']); $__env->pushConsumableComponentData(['wire:model' => 'product_id', 'placeholder' => 'Pilih produk...']); ?><select
    class="appearance-none [:where(&amp;)]:w-full ps-3 pe-10 block h-10 py-2 text-base sm:text-sm leading-[1.375rem] rounded-lg shadow-xs border bg-white dark:bg-white/10 dark:disabled:bg-white/[7%] text-zinc-700 dark:text-zinc-300 disabled:text-zinc-500 dark:disabled:text-zinc-400 has-[option.placeholder:checked]:text-zinc-400 dark:has-[option.placeholder:checked]:text-zinc-400 dark:[&amp;&gt;option]:bg-zinc-700 dark:[&amp;&gt;option]:text-white disabled:shadow-none border border-zinc-200 border-b-zinc-300/80 dark:border-white/10" wire:model="product_id"
         name="product_id"         data-flux-control
    data-flux-select-native
    data-flux-group-target
>
            <option value="" disabled selected class="placeholder">Pilih produk...</option>
    
    <?php ob_start(); ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php ob_start(); ?><option
    
     value="<?php echo e($product->id); ?>"      <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = ''.e($product->id).''; ?>wire:key="<?php echo e($product->id); ?>" ><?php ob_start(); ?><?php echo e($product->name); ?><?php echo trim(ob_get_clean()); ?></option><?php echo ltrim(ob_get_clean()); ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <?php echo trim(ob_get_clean()); ?>

</select>
<?php $__blaze->popData(); $__env->popConsumableComponentData(); ?><?php echo ltrim(ob_get_clean()); ?>
                <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/error.blade.php', $__blaze->compiledPath.'/15082528e22fca9254991cacf35a21b3.php'); ?>
<?php $__blaze->pushData(['name' => 'product_id']); ?>
<?php _15082528e22fca9254991cacf35a21b3($__blaze, ['name' => 'product_id'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
            <?php echo trim(ob_get_clean()); ?>

</ui-field>
<?php echo ltrim(ob_get_clean()); ?>

            <!-- Grid 2 kolom untuk Nama & Email -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <!-- Nama -->
                <?php ob_start(); ?><ui-field class="min-w-0 [&amp;:not(:has([data-flux-field])):has([data-flux-control][disabled])&gt;[data-flux-label]]:opacity-50 [&amp;:has(&gt;[data-flux-radio-group][disabled])&gt;[data-flux-label]]:opacity-50 [&amp;:has(&gt;[data-flux-checkbox-group][disabled])&gt;[data-flux-label]]:opacity-50 block *:data-flux-label:mb-3 [&amp;&gt;[data-flux-label]:has(+[data-flux-description])]:mb-2 [&amp;&gt;[data-flux-label]+[data-flux-description]]:mt-0 [&amp;&gt;[data-flux-label]+[data-flux-description]]:mb-3 [&amp;&gt;[data-flux-description]:first-child:has(+*)]:mb-3 [&amp;&gt;*:not([data-flux-label])+[data-flux-description]]:mt-3" data-flux-field>
    <?php ob_start(); ?>
                    <?php ob_start(); ?><ui-label class="inline-flex items-center text-sm font-medium  [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white [&amp;:has([data-flux-label-trailing])]:flex" data-flux-label>
    <?php ob_start(); ?>Nama Pengirim <span class="text-red-500">*</span><?php echo trim(ob_get_clean()); ?>


    
    
    </ui-label>
<?php echo ltrim(ob_get_clean()); ?>
                    <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/input/index.blade.php', $__blaze->compiledPath.'/7d4f1be85db8dbf791d2ec038e21b28f.php'); ?>
<?php $__blaze->pushData(['wire:model' => 'name','placeholder' => 'Masukkan nama']); ?>
<?php _7d4f1be85db8dbf791d2ec038e21b28f($__blaze, ['wire:model' => 'name','placeholder' => 'Masukkan nama'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                    <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/error.blade.php', $__blaze->compiledPath.'/15082528e22fca9254991cacf35a21b3.php'); ?>
<?php $__blaze->pushData(['name' => 'name']); ?>
<?php _15082528e22fca9254991cacf35a21b3($__blaze, ['name' => 'name'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php echo trim(ob_get_clean()); ?>

</ui-field>
<?php echo ltrim(ob_get_clean()); ?>

                <!-- Email -->
                <?php ob_start(); ?><ui-field class="min-w-0 [&amp;:not(:has([data-flux-field])):has([data-flux-control][disabled])&gt;[data-flux-label]]:opacity-50 [&amp;:has(&gt;[data-flux-radio-group][disabled])&gt;[data-flux-label]]:opacity-50 [&amp;:has(&gt;[data-flux-checkbox-group][disabled])&gt;[data-flux-label]]:opacity-50 block *:data-flux-label:mb-3 [&amp;&gt;[data-flux-label]:has(+[data-flux-description])]:mb-2 [&amp;&gt;[data-flux-label]+[data-flux-description]]:mt-0 [&amp;&gt;[data-flux-label]+[data-flux-description]]:mb-3 [&amp;&gt;[data-flux-description]:first-child:has(+*)]:mb-3 [&amp;&gt;*:not([data-flux-label])+[data-flux-description]]:mt-3" data-flux-field>
    <?php ob_start(); ?>
                    <?php ob_start(); ?><ui-label class="inline-flex items-center text-sm font-medium  [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white [&amp;:has([data-flux-label-trailing])]:flex" data-flux-label>
    <?php ob_start(); ?>Email (opsional)<?php echo trim(ob_get_clean()); ?>


    
    
    </ui-label>
<?php echo ltrim(ob_get_clean()); ?>
                    <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/input/index.blade.php', $__blaze->compiledPath.'/7d4f1be85db8dbf791d2ec038e21b28f.php'); ?>
<?php $__blaze->pushData(['wire:model' => 'email','type' => 'email','placeholder' => 'nama@email.com']); ?>
<?php _7d4f1be85db8dbf791d2ec038e21b28f($__blaze, ['wire:model' => 'email','type' => 'email','placeholder' => 'nama@email.com'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                    <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/error.blade.php', $__blaze->compiledPath.'/15082528e22fca9254991cacf35a21b3.php'); ?>
<?php $__blaze->pushData(['name' => 'email']); ?>
<?php _15082528e22fca9254991cacf35a21b3($__blaze, ['name' => 'email'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php echo trim(ob_get_clean()); ?>

</ui-field>
<?php echo ltrim(ob_get_clean()); ?>
            </div>

            <!-- Grid 2 kolom untuk Rating & Status -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                <!-- Rating -->
                <?php ob_start(); ?><ui-field class="min-w-0 [&amp;:not(:has([data-flux-field])):has([data-flux-control][disabled])&gt;[data-flux-label]]:opacity-50 [&amp;:has(&gt;[data-flux-radio-group][disabled])&gt;[data-flux-label]]:opacity-50 [&amp;:has(&gt;[data-flux-checkbox-group][disabled])&gt;[data-flux-label]]:opacity-50 block *:data-flux-label:mb-3 [&amp;&gt;[data-flux-label]:has(+[data-flux-description])]:mb-2 [&amp;&gt;[data-flux-label]+[data-flux-description]]:mt-0 [&amp;&gt;[data-flux-label]+[data-flux-description]]:mb-3 [&amp;&gt;[data-flux-description]:first-child:has(+*)]:mb-3 [&amp;&gt;*:not([data-flux-label])+[data-flux-description]]:mt-3" data-flux-field>
    <?php ob_start(); ?>
                    <?php ob_start(); ?><ui-label class="inline-flex items-center text-sm font-medium  [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white [&amp;:has([data-flux-label-trailing])]:flex" data-flux-label>
    <?php ob_start(); ?>Rating <span class="text-red-500">*</span><?php echo trim(ob_get_clean()); ?>


    
    
    </ui-label>
<?php echo ltrim(ob_get_clean()); ?>
                    <div class="flex gap-1 text-3xl select-none pt-1">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php for($i = 1; $i <= 5; $i++): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <button type="button" wire:click="setRating(<?php echo e($i); ?>)"
                                class="transition-transform hover:scale-110 <?php echo e($i <= $rating ? 'text-amber-400' : 'text-zinc-300 dark:text-zinc-600'); ?>">
                                ★
                            </button>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                    <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/error.blade.php', $__blaze->compiledPath.'/15082528e22fca9254991cacf35a21b3.php'); ?>
<?php $__blaze->pushData(['name' => 'rating']); ?>
<?php _15082528e22fca9254991cacf35a21b3($__blaze, ['name' => 'rating'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php echo trim(ob_get_clean()); ?>

</ui-field>
<?php echo ltrim(ob_get_clean()); ?>

                <!-- Status -->
                <?php ob_start(); ?><ui-field class="min-w-0 [&amp;:not(:has([data-flux-field])):has([data-flux-control][disabled])&gt;[data-flux-label]]:opacity-50 [&amp;:has(&gt;[data-flux-radio-group][disabled])&gt;[data-flux-label]]:opacity-50 [&amp;:has(&gt;[data-flux-checkbox-group][disabled])&gt;[data-flux-label]]:opacity-50 block *:data-flux-label:mb-3 [&amp;&gt;[data-flux-label]:has(+[data-flux-description])]:mb-2 [&amp;&gt;[data-flux-label]+[data-flux-description]]:mt-0 [&amp;&gt;[data-flux-label]+[data-flux-description]]:mb-3 [&amp;&gt;[data-flux-description]:first-child:has(+*)]:mb-3 [&amp;&gt;*:not([data-flux-label])+[data-flux-description]]:mt-3" data-flux-field>
    <?php ob_start(); ?>
                    <?php ob_start(); ?><ui-label class="inline-flex items-center text-sm font-medium  [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white [&amp;:has([data-flux-label-trailing])]:flex" data-flux-label>
    <?php ob_start(); ?>Status <span class="text-red-500">*</span><?php echo trim(ob_get_clean()); ?>


    
    
    </ui-label>
<?php echo ltrim(ob_get_clean()); ?>
                    <?php ob_start(); ?><?php $__blaze->pushData(['wire:model' => 'status']); $__env->pushConsumableComponentData(['wire:model' => 'status']); ?><select
    class="appearance-none [:where(&amp;)]:w-full ps-3 pe-10 block h-10 py-2 text-base sm:text-sm leading-[1.375rem] rounded-lg shadow-xs border bg-white dark:bg-white/10 dark:disabled:bg-white/[7%] text-zinc-700 dark:text-zinc-300 disabled:text-zinc-500 dark:disabled:text-zinc-400 has-[option.placeholder:checked]:text-zinc-400 dark:has-[option.placeholder:checked]:text-zinc-400 dark:[&amp;&gt;option]:bg-zinc-700 dark:[&amp;&gt;option]:text-white disabled:shadow-none border border-zinc-200 border-b-zinc-300/80 dark:border-white/10" wire:model="status"
         name="status"         data-flux-control
    data-flux-select-native
    data-flux-group-target
>
    
    <?php ob_start(); ?>
                        <?php ob_start(); ?><option
    
     value="pending"      <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'pending'; ?>wire:key="pending" ><?php ob_start(); ?>Pending<?php echo trim(ob_get_clean()); ?></option><?php echo ltrim(ob_get_clean()); ?>
                        <?php ob_start(); ?><option
    
     value="approved"      <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'approved'; ?>wire:key="approved" ><?php ob_start(); ?>Disetujui<?php echo trim(ob_get_clean()); ?></option><?php echo ltrim(ob_get_clean()); ?>
                        <?php ob_start(); ?><option
    
     value="rejected"      <?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::$currentLoop['key'] = 'rejected'; ?>wire:key="rejected" ><?php ob_start(); ?>Ditolak<?php echo trim(ob_get_clean()); ?></option><?php echo ltrim(ob_get_clean()); ?>
                    <?php echo trim(ob_get_clean()); ?>

</select>
<?php $__blaze->popData(); $__env->popConsumableComponentData(); ?><?php echo ltrim(ob_get_clean()); ?>
                    <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/error.blade.php', $__blaze->compiledPath.'/15082528e22fca9254991cacf35a21b3.php'); ?>
<?php $__blaze->pushData(['name' => 'status']); ?>
<?php _15082528e22fca9254991cacf35a21b3($__blaze, ['name' => 'status'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php echo trim(ob_get_clean()); ?>

</ui-field>
<?php echo ltrim(ob_get_clean()); ?>
            </div>

            <!-- Komentar (Full Width) -->
            <?php ob_start(); ?><ui-field class="min-w-0 [&amp;:not(:has([data-flux-field])):has([data-flux-control][disabled])&gt;[data-flux-label]]:opacity-50 [&amp;:has(&gt;[data-flux-radio-group][disabled])&gt;[data-flux-label]]:opacity-50 [&amp;:has(&gt;[data-flux-checkbox-group][disabled])&gt;[data-flux-label]]:opacity-50 block *:data-flux-label:mb-3 [&amp;&gt;[data-flux-label]:has(+[data-flux-description])]:mb-2 [&amp;&gt;[data-flux-label]+[data-flux-description]]:mt-0 [&amp;&gt;[data-flux-label]+[data-flux-description]]:mb-3 [&amp;&gt;[data-flux-description]:first-child:has(+*)]:mb-3 [&amp;&gt;*:not([data-flux-label])+[data-flux-description]]:mt-3" data-flux-field>
    <?php ob_start(); ?>
                <?php ob_start(); ?><ui-label class="inline-flex items-center text-sm font-medium  [:where(&amp;)]:text-zinc-800 [:where(&amp;)]:dark:text-white [&amp;:has([data-flux-label-trailing])]:flex" data-flux-label>
    <?php ob_start(); ?>Isi Ulasan <span class="text-red-500">*</span><?php echo trim(ob_get_clean()); ?>


    
    
    </ui-label>
<?php echo ltrim(ob_get_clean()); ?>
                <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/textarea.blade.php', $__blaze->compiledPath.'/eff5bd261383d44a2eed294a7e8cd52b.php'); ?>
<?php $__blaze->pushData(['wire:model' => 'comment','rows' => '4','placeholder' => 'Tulis ulasan produk...']); ?>
<?php _eff5bd261383d44a2eed294a7e8cd52b($__blaze, ['wire:model' => 'comment','rows' => '4','placeholder' => 'Tulis ulasan produk...'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
                <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/error.blade.php', $__blaze->compiledPath.'/15082528e22fca9254991cacf35a21b3.php'); ?>
<?php $__blaze->pushData(['name' => 'comment']); ?>
<?php _15082528e22fca9254991cacf35a21b3($__blaze, ['name' => 'comment'], [], [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
            <?php echo trim(ob_get_clean()); ?>

</ui-field>
<?php echo ltrim(ob_get_clean()); ?>

            <!-- Actions -->
            <div class="flex justify-end gap-2 pt-2">
                <?php ob_start(); ?><button type="button" class="relative items-center font-medium justify-center gap-2 whitespace-nowrap disabled:opacity-75 dark:disabled:opacity-75 disabled:cursor-default disabled:pointer-events-none justify-center h-10 text-sm rounded-lg ps-4 pe-4 inline-flex  bg-transparent hover:bg-zinc-800/5 dark:hover:bg-white/15 text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-white    *:transition-opacity [&amp;[data-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-flux-loading]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[data-loading]&gt;[data-flux-loading-indicator]]:opacity-100 [&amp;[data-flux-loading]&gt;[data-flux-loading-indicator]]:opacity-100 data-loading:pointer-events-none data-flux-loading:pointer-events-none" data-flux-button="data-flux-button" wire:target="closeModal" wire:loading.attr="data-flux-loading" wire:click="closeModal">
        <div class="absolute inset-0 flex items-center justify-center opacity-0" data-flux-loading-indicator>
                <svg class="shrink-0 [:where(&amp;)]:size-4 animate-spin" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true" data-slot="icon">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
</svg>
                    </div>
        
        
                    
            
            <span><?php ob_start(); ?>
                    Batal
                <?php echo trim(ob_get_clean()); ?></span>
    </button>
<?php echo ltrim(ob_get_clean()); ?>
                <?php ob_start(); ?><button type="submit" class="relative items-center font-medium justify-center gap-2 whitespace-nowrap disabled:opacity-75 dark:disabled:opacity-75 disabled:cursor-default disabled:pointer-events-none justify-center h-10 text-sm rounded-lg ps-4 pe-4 inline-flex  bg-[var(--color-accent)] hover:bg-[color-mix(in_oklab,_var(--color-accent),_transparent_10%)] text-[var(--color-accent-foreground)] border border-black/10 dark:border-0 shadow-[inset_0px_1px_--theme(--color-white/.2)] [[data-flux-button-group]_&amp;]:border-e-0 [:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-[1px] dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-e-0 dark:[:is([data-flux-button-group]&gt;&amp;:last-child,_[data-flux-button-group]_:last-child&gt;&amp;)]:border-s-[1px] [:is([data-flux-button-group]&gt;&amp;:not(:first-child),_[data-flux-button-group]_:not(:first-child)&gt;&amp;)]:border-s-[color-mix(in_srgb,var(--color-accent-foreground),transparent_85%)] *:transition-opacity [&amp;[disabled]&gt;:not([data-flux-loading-indicator])]:opacity-0 [&amp;[disabled]&gt;[data-flux-loading-indicator]]:opacity-100 [&amp;[disabled]]:pointer-events-none" data-flux-button="data-flux-button" data-flux-group-target="data-flux-group-target" wire:loading.attr="disabled" wire:target="save">
        <div class="absolute inset-0 flex items-center justify-center opacity-0" data-flux-loading-indicator>
                <svg class="shrink-0 [:where(&amp;)]:size-4 animate-spin" data-flux-icon xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" aria-hidden="true" data-slot="icon">
    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
</svg>
                    </div>
        
        
                    
            
            <span><?php ob_start(); ?>
                    <span wire:loading.remove wire:target="save">
                        <?php echo e($editingId ? 'Simpan Perubahan' : 'Tambah Ulasan'); ?>

                    </span>
                    <span wire:loading wire:target="save">Menyimpan...</span>
                <?php echo trim(ob_get_clean()); ?></span>
    </button>
<?php echo ltrim(ob_get_clean()); ?>
            </div>
        </form>
    <?php $__slots44e4610bfcfca018bf54460c1f0baace['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots44e4610bfcfca018bf54460c1f0baace); ?>
<?php _44e4610bfcfca018bf54460c1f0baace($__blaze, $__attrs44e4610bfcfca018bf54460c1f0baace, $__slots44e4610bfcfca018bf54460c1f0baace, [], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack44e4610bfcfca018bf54460c1f0baace)) { $__slots44e4610bfcfca018bf54460c1f0baace = array_pop($__slotsStack44e4610bfcfca018bf54460c1f0baace); } ?>
<?php if (! empty($__attrsStack44e4610bfcfca018bf54460c1f0baace)) { $__attrs44e4610bfcfca018bf54460c1f0baace = array_pop($__attrsStack44e4610bfcfca018bf54460c1f0baace); } ?>
<?php $__blaze->popData(); ?>
</div>
<?php /**PATH C:\laragon\www\bossed-landig-page\resources\views/livewire/admin/review-index.blade.php ENDPATH**/ ?>