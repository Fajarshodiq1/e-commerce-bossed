<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Title & SEO Dasar -->
    <title><?php echo e($metaTitle ?? 'Vendor Corporate Merchandise Kulit Premium & Custom Kit | Bossed'); ?></title>
    <meta name="description"
        content="<?php echo e($metaDescription ?? 'Pusat pembuatan corporate merchandise & gift set berbahan kulit premium. Custom logo untuk seminar kit, welcome kit, & hampers perusahaan.'); ?>">
    <meta name="keywords"
        content="<?php echo e($metaKeywords ?? 'corporate merchandise kulit, souvenir perusahaan, vendor gift set, seminar kit custom, hampers kulit'); ?>">
    <meta name="robots" content="<?php echo e($metaRobots ?? 'index, follow'); ?>">
    <meta name="author" content="Bossed Corporate Merchandise">
    <link rel="canonical" href="<?php echo e(url()->current()); ?>">

    <!-- Branding UI Browser & Mobile Theme -->
    <meta name="theme-color" content="#1a2923"> <!-- Warna tema status bar browser mobile -->

    <!-- ========================================================= -->
    <!-- FAVICON & APPLE TOUCH ICON (Cukup Menggunakan 1 Logo Utama) -->
    <!-- ========================================================= -->
    <!-- Favicon Browser Tab (Desktop/Mobile) -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/BOOSED_LOGO.png')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/BOOSED_LOGO.png')); ?>" type="image/x-icon">

    <!-- Apple Touch Icon (Aplikasi Layar Utama iPhone / iPad) -->
    <link rel="apple-touch-icon" href="<?php echo e(asset('assets/BOOSED_LOGO.png')); ?>">

    <!-- Open Graph / Facebook / WhatsApp Sharing -->
    <meta property="og:type" content="<?php echo e($metaType ?? 'website'); ?>">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta property="og:title" content="<?php echo e($metaTitle ?? 'Vendor Corporate Merchandise Kulit Premium | Bossed'); ?>">
    <meta property="og:description"
        content="<?php echo e($metaDescription ?? 'Pusat pembuatan corporate merchandise & gift set berbahan kulit premium. Custom logo untuk seminar kit, welcome kit, & hampers perusahaan.'); ?>">
    <meta property="og:image" content="<?php echo e($metaImage ?? asset('assets/BOOSED_LOGO.png')); ?>">
    <meta property="og:image:secure_url" content="<?php echo e($metaImage ?? asset('assets/BOOSED_LOGO.png')); ?>">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:alt" content="<?php echo e($metaTitle ?? 'Bossed Corporate Merchandise'); ?>">
    <meta property="og:site_name" content="<?php echo e(config('app.name', 'Bossed')); ?>">
    <meta property="og:locale" content="id_ID">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo e($metaTitle ?? 'Vendor Corporate Merchandise Kulit Premium | Bossed'); ?>">
    <meta name="twitter:description"
        content="<?php echo e($metaDescription ?? 'Pusat pembuatan corporate merchandise & gift set berbahan kulit premium. Custom logo untuk seminar kit, welcome kit, & hampers perusahaan.'); ?>">
    <meta name="twitter:image" content="<?php echo e($metaImage ?? asset('assets/BOOSED_LOGO.png')); ?>">

    <!-- Keamanan / Referrer Policy -->
    <meta name="referrer" content="no-referrer-when-downgrade">

    <!-- Slot Khusus Schema.org JSON-LD Structured Data -->
    <?php echo $__env->yieldPushContent('schema'); ?>

    <style>
        @keyframes marquee {
            0% {
                transform: translateX(0%);
            }

            100% {
                transform: translateX(-100%);
            }
        }

        .animate-marquee {
            animation: marquee 25s linear infinite;
        }
    </style>

    <!-- Asset Vite (Tailwind CSS & JavaScript) -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body class="bg-gray-50 font-sans text-gray-900 antialiased">
    <!-- Header / Navbar Public -->
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(view()->exists('components.public-header')): ?>
        <?php if (isset($component)) { $__componentOriginal2669d93ac3865159955b6d09c48349b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2669d93ac3865159955b6d09c48349b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2669d93ac3865159955b6d09c48349b9)): ?>
<?php $attributes = $__attributesOriginal2669d93ac3865159955b6d09c48349b9; ?>
<?php unset($__attributesOriginal2669d93ac3865159955b6d09c48349b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2669d93ac3865159955b6d09c48349b9)): ?>
<?php $component = $__componentOriginal2669d93ac3865159955b6d09c48349b9; ?>
<?php unset($__componentOriginal2669d93ac3865159955b6d09c48349b9); ?>
<?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <!-- Main Content Dynamic Slot -->
    <main class="min-h-screen">
        <?php echo e($slot); ?>

    </main>

    <!-- Dynamic Floating WhatsApp CTA Button -->
    


    <?php if (isset($component)) { $__componentOriginal2702f386a0a6c0cb365c22db0bdb7e06 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2702f386a0a6c0cb365c22db0bdb7e06 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.public-footer','data' => ['storeName' => $storeName,'description' => $description,'whatsappNumber' => $whatsappNumber,'email' => $email,'address' => $address,'instagramUrl' => $instagramUrl,'facebookUrl' => $facebookUrl,'twitterUrl' => $twitterUrl,'youtubeUrl' => $youtubeUrl,'tiktokUrl' => $tiktokUrl]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('public-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['store-name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($storeName),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($description),'whatsapp-number' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($whatsappNumber),'email' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($email),'address' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($address),'instagram-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($instagramUrl),'facebook-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($facebookUrl),'twitter-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($twitterUrl),'youtube-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($youtubeUrl),'tiktok-url' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tiktokUrl)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2702f386a0a6c0cb365c22db0bdb7e06)): ?>
<?php $attributes = $__attributesOriginal2702f386a0a6c0cb365c22db0bdb7e06; ?>
<?php unset($__attributesOriginal2702f386a0a6c0cb365c22db0bdb7e06); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2702f386a0a6c0cb365c22db0bdb7e06)): ?>
<?php $component = $__componentOriginal2702f386a0a6c0cb365c22db0bdb7e06; ?>
<?php unset($__componentOriginal2702f386a0a6c0cb365c22db0bdb7e06); ?>
<?php endif; ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>

</html>
<?php /**PATH C:\laragon\www\bossed-landig-page\resources\views/layouts/public.blade.php ENDPATH**/ ?>