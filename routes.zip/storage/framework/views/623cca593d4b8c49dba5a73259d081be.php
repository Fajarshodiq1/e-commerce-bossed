<div>
    <!-- SECTION 1: HERO -->
    <?php if (isset($component)) { $__componentOriginala038281ce129721dd88a49670137597b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala038281ce129721dd88a49670137597b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.hero-section','data' => ['heroImage' => $heroImage,'storeName' => $storeName,'waNumber' => $waNumber]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hero-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['hero-image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($heroImage),'store-name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($storeName),'wa-number' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($waNumber)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala038281ce129721dd88a49670137597b)): ?>
<?php $attributes = $__attributesOriginala038281ce129721dd88a49670137597b; ?>
<?php unset($__attributesOriginala038281ce129721dd88a49670137597b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala038281ce129721dd88a49670137597b)): ?>
<?php $component = $__componentOriginala038281ce129721dd88a49670137597b; ?>
<?php unset($__componentOriginala038281ce129721dd88a49670137597b); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal2f906c7b72b7f488716a138bd805a1ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f906c7b72b7f488716a138bd805a1ae = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.about-section','data' => ['storeName' => $storeName ?? 'Bossed','aboutImage' => $aboutImage ?? null]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('about-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['store-name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($storeName ?? 'Bossed'),'about-image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($aboutImage ?? null)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f906c7b72b7f488716a138bd805a1ae)): ?>
<?php $attributes = $__attributesOriginal2f906c7b72b7f488716a138bd805a1ae; ?>
<?php unset($__attributesOriginal2f906c7b72b7f488716a138bd805a1ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f906c7b72b7f488716a138bd805a1ae)): ?>
<?php $component = $__componentOriginal2f906c7b72b7f488716a138bd805a1ae; ?>
<?php unset($__componentOriginal2f906c7b72b7f488716a138bd805a1ae); ?>
<?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($productLineups->isNotEmpty()): ?>
        <section class="py-12 bg-white dark:bg-zinc-900 overflow-hidden border-y-2 border-[#4e3027] mt-3">
            <div class="relative w-full overflow-hidden">
                <!-- Gradient fade kiri & kanan -->
                <div
                    class="pointer-events-none absolute left-0 top-0 h-full w-16 md:w-32 z-10 bg-gradient-to-r from-white dark:from-zinc-900 to-transparent">
                </div>
                <div
                    class="pointer-events-none absolute right-0 top-0 h-full w-16 md:w-32 z-10 bg-gradient-to-l from-white dark:from-zinc-900 to-transparent">
                </div>

                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isLoading ?? false): ?>
                    <div class="flex gap-6 w-max animate-pulse">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php for($s = 0; $s < 8; $s++): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <div
                                class="relative flex-shrink-0 w-48 h-60 rounded-xl overflow-hidden bg-zinc-200 dark:bg-zinc-800 border border-zinc-300/50 dark:border-zinc-700/50 flex flex-col justify-end p-4">
                                
                                <div class="h-4 bg-zinc-300 dark:bg-zinc-700 rounded-md w-3/4 mb-2"></div>
                                
                                <div class="h-3 bg-zinc-300 dark:bg-zinc-700 rounded-md w-1/2"></div>
                            </div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>

                    
                <?php else: ?>
                    <div class="marquee-track flex gap-6 w-max">
                        
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php for($i = 0; $i < 4; $i++): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $productLineups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <div class="group relative flex-shrink-0 w-48 h-60 rounded-xl overflow-hidden border border-zinc-200 dark:border-zinc-700 shadow-sm bg-zinc-100 dark:bg-zinc-800"
                                    <?php if($i > 0): ?> aria-hidden="true" <?php endif; ?>>

                                    
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $item->image)); ?>"
                                            alt="<?php echo e($i === 0 ? $item->name : ''); ?>"
                                            class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                                            width="192" height="240" loading="lazy" />
                                    <?php else: ?>
                                        <div
                                            class="w-full h-full bg-zinc-200 dark:bg-zinc-800 flex items-center justify-center text-zinc-400 text-xs">
                                            No Image
                                        </div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                    
                                    <div
                                        class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4 text-white">
                                        <div class="font-medium text-sm text-white truncate drop-shadow-sm">
                                            <?php echo e($item->name); ?>

                                        </div>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->price): ?>
                                            <div class="text-xs text-zinc-200 mt-1 font-semibold drop-shadow-sm">
                                                Rp <?php echo e(number_format($item->price, 0, ',', '.')); ?>

                                            </div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>

                                </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </section>

        <style>
            .marquee-track {
                display: flex;
                width: max-content;
                will-change: transform;
                animation: marquee-scroll 15s linear infinite;
                transform: translate3d(0, 0, 0);
                backface-visibility: hidden;
                -webkit-backface-visibility: hidden;
            }

            .marquee-track:hover {
                animation-play-state: paused;
            }

            @keyframes marquee-scroll {
                0% {
                    transform: translate3d(0, 0, 0);
                }

                100% {
                    transform: translate3d(calc(-25% - 0.375rem), 0, 0);
                }
            }
        </style>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if (isset($component)) { $__componentOriginale22aa802c5da24d7f3436e80a9a4dc9f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale22aa802c5da24d7f3436e80a9a4dc9f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.why-us-section','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('why-us-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale22aa802c5da24d7f3436e80a9a4dc9f)): ?>
<?php $attributes = $__attributesOriginale22aa802c5da24d7f3436e80a9a4dc9f; ?>
<?php unset($__attributesOriginale22aa802c5da24d7f3436e80a9a4dc9f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale22aa802c5da24d7f3436e80a9a4dc9f)): ?>
<?php $component = $__componentOriginale22aa802c5da24d7f3436e80a9a4dc9f; ?>
<?php unset($__componentOriginale22aa802c5da24d7f3436e80a9a4dc9f); ?>
<?php endif; ?>
    <!-- SECTION 2: KATEGORI POPULER -->
    <?php if (isset($component)) { $__componentOriginal05fc53a23296c7496b3765fe64fd4b35 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal05fc53a23296c7496b3765fe64fd4b35 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.category-section','data' => ['categories' => $categories,'selectedCategory' => $selectedCategory]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('category-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['categories' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categories),'selectedCategory' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($selectedCategory)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal05fc53a23296c7496b3765fe64fd4b35)): ?>
<?php $attributes = $__attributesOriginal05fc53a23296c7496b3765fe64fd4b35; ?>
<?php unset($__attributesOriginal05fc53a23296c7496b3765fe64fd4b35); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal05fc53a23296c7496b3765fe64fd4b35)): ?>
<?php $component = $__componentOriginal05fc53a23296c7496b3765fe64fd4b35; ?>
<?php unset($__componentOriginal05fc53a23296c7496b3765fe64fd4b35); ?>
<?php endif; ?>

    <!-- SECTION 3: KATALOG PRODUK -->
    <?php if (isset($component)) { $__componentOriginal29cde30777e80a6de1b3f7542525e376 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal29cde30777e80a6de1b3f7542525e376 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-section','data' => ['products' => $products,'selectedCategory' => $selectedCategory,'search' => $search,'sort' => $sort]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products),'selectedCategory' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($selectedCategory),'search' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($search),'sort' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sort)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal29cde30777e80a6de1b3f7542525e376)): ?>
<?php $attributes = $__attributesOriginal29cde30777e80a6de1b3f7542525e376; ?>
<?php unset($__attributesOriginal29cde30777e80a6de1b3f7542525e376); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal29cde30777e80a6de1b3f7542525e376)): ?>
<?php $component = $__componentOriginal29cde30777e80a6de1b3f7542525e376; ?>
<?php unset($__componentOriginal29cde30777e80a6de1b3f7542525e376); ?>
<?php endif; ?>

    <!-- SECTION 4: TESTIMONIAL -->
    <?php if (isset($component)) { $__componentOriginalbe61e62b0ca073fe23446d29279a6620 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe61e62b0ca073fe23446d29279a6620 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.trust-section','data' => ['testimonials' => $testimonials]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('trust-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['testimonials' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($testimonials)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe61e62b0ca073fe23446d29279a6620)): ?>
<?php $attributes = $__attributesOriginalbe61e62b0ca073fe23446d29279a6620; ?>
<?php unset($__attributesOriginalbe61e62b0ca073fe23446d29279a6620); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe61e62b0ca073fe23446d29279a6620)): ?>
<?php $component = $__componentOriginalbe61e62b0ca073fe23446d29279a6620; ?>
<?php unset($__componentOriginalbe61e62b0ca073fe23446d29279a6620); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginald509f1dd991e98b5837bfe6e90a061dc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald509f1dd991e98b5837bfe6e90a061dc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.faq-section','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('faq-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald509f1dd991e98b5837bfe6e90a061dc)): ?>
<?php $attributes = $__attributesOriginald509f1dd991e98b5837bfe6e90a061dc; ?>
<?php unset($__attributesOriginald509f1dd991e98b5837bfe6e90a061dc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald509f1dd991e98b5837bfe6e90a061dc)): ?>
<?php $component = $__componentOriginald509f1dd991e98b5837bfe6e90a061dc; ?>
<?php unset($__componentOriginald509f1dd991e98b5837bfe6e90a061dc); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\bossed-landig-page\resources\views/livewire/public/home-index.blade.php ENDPATH**/ ?>