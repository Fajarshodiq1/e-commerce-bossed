<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'sidebar' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'sidebar' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sidebar): ?>
    <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/sidebar/brand.blade.php', $__blaze->compiledPath.'/b32b2dbe073289373ce8dc96cac8bc80.php'); ?>
<?php if (isset($__slotsb32b2dbe073289373ce8dc96cac8bc80)) { $__slotsStackb32b2dbe073289373ce8dc96cac8bc80[] = $__slotsb32b2dbe073289373ce8dc96cac8bc80; } ?>
<?php if (isset($__attrsb32b2dbe073289373ce8dc96cac8bc80)) { $__attrsStackb32b2dbe073289373ce8dc96cac8bc80[] = $__attrsb32b2dbe073289373ce8dc96cac8bc80; } ?>
<?php $__attrsb32b2dbe073289373ce8dc96cac8bc80 = ['name' => config('app.name', 'Laravel'),'attributes' => $attributes]; ?>
<?php $__slotsb32b2dbe073289373ce8dc96cac8bc80 = []; ?>
<?php $__blaze->pushData($__attrsb32b2dbe073289373ce8dc96cac8bc80); ?>
<?php ob_start(); ?>
         <?php ob_start(); ?>
            <?php if (isset($component)) { $__componentOriginal159d6670770cb479b1921cea6416c26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159d6670770cb479b1921cea6416c26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-logo-icon','data' => ['class' => 'size-5 fill-current text-white dark:text-black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-logo-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5 fill-current text-white dark:text-black']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $attributes = $__attributesOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__attributesOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $component = $__componentOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__componentOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
        <?php $__slotsb32b2dbe073289373ce8dc96cac8bc80['logo'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), ['class' => 'flex aspect-square size-8 items-center justify-center rounded-md  text-accent-foreground']); ?>
    <?php $__slotsb32b2dbe073289373ce8dc96cac8bc80['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slotsb32b2dbe073289373ce8dc96cac8bc80); ?>
<?php _b32b2dbe073289373ce8dc96cac8bc80($__blaze, $__attrsb32b2dbe073289373ce8dc96cac8bc80, $__slotsb32b2dbe073289373ce8dc96cac8bc80, ['name', 'attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStackb32b2dbe073289373ce8dc96cac8bc80)) { $__slotsb32b2dbe073289373ce8dc96cac8bc80 = array_pop($__slotsStackb32b2dbe073289373ce8dc96cac8bc80); } ?>
<?php if (! empty($__attrsStackb32b2dbe073289373ce8dc96cac8bc80)) { $__attrsb32b2dbe073289373ce8dc96cac8bc80 = array_pop($__attrsStackb32b2dbe073289373ce8dc96cac8bc80); } ?>
<?php $__blaze->popData(); ?>
<?php else: ?>
    <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/brand.blade.php', $__blaze->compiledPath.'/4512e4fba9c7a4396523fe8a36ce0da1.php'); ?>
<?php if (isset($__slots4512e4fba9c7a4396523fe8a36ce0da1)) { $__slotsStack4512e4fba9c7a4396523fe8a36ce0da1[] = $__slots4512e4fba9c7a4396523fe8a36ce0da1; } ?>
<?php if (isset($__attrs4512e4fba9c7a4396523fe8a36ce0da1)) { $__attrsStack4512e4fba9c7a4396523fe8a36ce0da1[] = $__attrs4512e4fba9c7a4396523fe8a36ce0da1; } ?>
<?php $__attrs4512e4fba9c7a4396523fe8a36ce0da1 = ['name' => config('app.name', 'Laravel'),'attributes' => $attributes]; ?>
<?php $__slots4512e4fba9c7a4396523fe8a36ce0da1 = []; ?>
<?php $__blaze->pushData($__attrs4512e4fba9c7a4396523fe8a36ce0da1); ?>
<?php ob_start(); ?>
         <?php ob_start(); ?>
            <?php if (isset($component)) { $__componentOriginal159d6670770cb479b1921cea6416c26c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal159d6670770cb479b1921cea6416c26c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-logo-icon','data' => ['class' => 'size-5 fill-current text-white dark:text-black']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-logo-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5 fill-current text-white dark:text-black']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $attributes = $__attributesOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__attributesOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal159d6670770cb479b1921cea6416c26c)): ?>
<?php $component = $__componentOriginal159d6670770cb479b1921cea6416c26c; ?>
<?php unset($__componentOriginal159d6670770cb479b1921cea6416c26c); ?>
<?php endif; ?>
        <?php $__slots4512e4fba9c7a4396523fe8a36ce0da1['logo'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), ['class' => 'flex aspect-square size-8 items-center justify-center rounded-md  text-accent-foreground']); ?>
    <?php $__slots4512e4fba9c7a4396523fe8a36ce0da1['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots4512e4fba9c7a4396523fe8a36ce0da1); ?>
<?php _4512e4fba9c7a4396523fe8a36ce0da1($__blaze, $__attrs4512e4fba9c7a4396523fe8a36ce0da1, $__slots4512e4fba9c7a4396523fe8a36ce0da1, ['name', 'attributes'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack4512e4fba9c7a4396523fe8a36ce0da1)) { $__slots4512e4fba9c7a4396523fe8a36ce0da1 = array_pop($__slotsStack4512e4fba9c7a4396523fe8a36ce0da1); } ?>
<?php if (! empty($__attrsStack4512e4fba9c7a4396523fe8a36ce0da1)) { $__attrs4512e4fba9c7a4396523fe8a36ce0da1 = array_pop($__attrsStack4512e4fba9c7a4396523fe8a36ce0da1); } ?>
<?php $__blaze->popData(); ?>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH C:\laragon\www\bossed-landig-page\resources\views/components/app-logo.blade.php ENDPATH**/ ?>