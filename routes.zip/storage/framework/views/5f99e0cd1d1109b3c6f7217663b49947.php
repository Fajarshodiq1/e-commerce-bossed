<?php
if (!function_exists('_5f99e0cd1d1109b3c6f7217663b49947')):
function _5f99e0cd1d1109b3c6f7217663b49947($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;

if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'iconVariant' => 'mini',
    'size' => null,
];
$iconVariant ??= $attributes['icon-variant'] ?? $attributes['iconVariant'] ?? $__defaults['iconVariant']; unset($attributes['iconVariant'], $attributes['icon-variant']);
$size ??= $attributes['size'] ?? $__defaults['size']; unset($attributes['size']);
unset($__defaults);
?>

<?php
$attributes = $attributes->merge([
    'variant' => 'subtle',
    'class' => '-me-1',
    'square' => true,
    'size' => null,
]);
?>

<?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/button/index.blade.php', $__blaze->compiledPath.'/44befdf667a8bbc607e3c8a333ca98af.php'); ?>
<?php if (isset($__slots44befdf667a8bbc607e3c8a333ca98af)) { $__slotsStack44befdf667a8bbc607e3c8a333ca98af[] = $__slots44befdf667a8bbc607e3c8a333ca98af; } ?>
<?php if (isset($__attrs44befdf667a8bbc607e3c8a333ca98af)) { $__attrsStack44befdf667a8bbc607e3c8a333ca98af[] = $__attrs44befdf667a8bbc607e3c8a333ca98af; } ?>
<?php $__attrs44befdf667a8bbc607e3c8a333ca98af = ['attributes' => $attributes,'size' => $size === 'sm' || $size === 'xs' ? 'xs' : 'sm','xData' => 'fluxInputViewable','xOn:click' => 'toggle()','xBind:dataViewableOpen' => 'open','ariaLabel' => e(__('Toggle password visibility'))]; ?>
<?php $__slots44befdf667a8bbc607e3c8a333ca98af = []; ?>
<?php $__blaze->pushData($__attrs44befdf667a8bbc607e3c8a333ca98af); ?>
<?php ob_start(); ?>
    <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/eye-slash.blade.php', $__blaze->compiledPath.'/6b41df16ff6ec5923d6e3b4644e2f2c5.php'); ?>
<?php $__blaze->pushData(['variant' => $iconVariant,'class' => 'hidden [[data-viewable-open]>&]:block']); ?>
<?php _6b41df16ff6ec5923d6e3b4644e2f2c5($__blaze, ['variant' => $iconVariant,'class' => 'hidden [[data-viewable-open]>&]:block'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
    <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/icon/eye.blade.php', $__blaze->compiledPath.'/3bf3a9758f56cec85065b8d8ec1a1314.php'); ?>
<?php $__blaze->pushData(['variant' => $iconVariant,'class' => 'block [[data-viewable-open]>&]:hidden']); ?>
<?php _3bf3a9758f56cec85065b8d8ec1a1314($__blaze, ['variant' => $iconVariant,'class' => 'block [[data-viewable-open]>&]:hidden'], [], ['variant'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php $__blaze->popData(); ?>
<?php $__slots44befdf667a8bbc607e3c8a333ca98af['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots44befdf667a8bbc607e3c8a333ca98af); ?>
<?php _44befdf667a8bbc607e3c8a333ca98af($__blaze, $__attrs44befdf667a8bbc607e3c8a333ca98af, $__slots44befdf667a8bbc607e3c8a333ca98af, ['attributes', 'size'], ['xData' => 'x-data', 'xOn:click' => 'x-on:click', 'xBind:dataViewableOpen' => 'x-bind:data-viewable-open', 'ariaLabel' => 'aria-label'], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack44befdf667a8bbc607e3c8a333ca98af)) { $__slots44befdf667a8bbc607e3c8a333ca98af = array_pop($__slotsStack44befdf667a8bbc607e3c8a333ca98af); } ?>
<?php if (! empty($__attrsStack44befdf667a8bbc607e3c8a333ca98af)) { $__attrs44befdf667a8bbc607e3c8a333ca98af = array_pop($__attrsStack44befdf667a8bbc607e3c8a333ca98af); } ?>
<?php $__blaze->popData(); ?>
<?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/input/viewable.blade.php ENDPATH**/ ?>