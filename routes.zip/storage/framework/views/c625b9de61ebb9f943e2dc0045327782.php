<?php
if (!function_exists('_c625b9de61ebb9f943e2dc0045327782')):
function _c625b9de61ebb9f943e2dc0045327782($__blaze, $__data = [], $__slots = [], $__bound = [], $__keys = [], $__this = null) {
$__env = $__blaze->env;
$__slots['slot'] ??= new \Illuminate\View\ComponentSlot('');
if (($__data['attributes'] ?? null) instanceof \Illuminate\View\ComponentAttributeBag) { $__data = $__data + $__data['attributes']->all(); unset($__data['attributes']); }
extract($__slots, EXTR_SKIP); unset($__slots);
extract($__data, EXTR_SKIP);
$attributes = \Livewire\Blaze\Runtime\BlazeAttributeBag::make($__data, $__bound, $__keys);
unset($__data, $__bound, $__keys);
ob_start();
?>


<?php
$__defaults = [
    'interactive' => null,
    'position' => 'top',
    'align' => 'center',
    'content' => null,
    'kbd' => null,
    'toggleable' => null,
];
$interactive ??= $attributes['interactive'] ?? $__defaults['interactive']; unset($attributes['interactive']);
$position ??= $attributes['position'] ?? $__defaults['position']; unset($attributes['position']);
$align ??= $attributes['align'] ?? $__defaults['align']; unset($attributes['align']);
$content ??= $attributes['content'] ?? $__defaults['content']; unset($attributes['content']);
$kbd ??= $attributes['kbd'] ?? $__defaults['kbd']; unset($attributes['kbd']);
$toggleable ??= $attributes['toggleable'] ?? $__defaults['toggleable']; unset($attributes['toggleable']);
unset($__defaults);
?>

<?php
// Support adding the .self modifier to the wire:model directive...
if (($wireModel = $attributes->wire('model')) && $wireModel->directive && ! $wireModel->hasModifier('self')) {
    unset($attributes[$wireModel->directive]);

    $wireModel->directive .= '.self';

    $attributes = $attributes->merge([$wireModel->directive => $wireModel->value]);
}
?>

<?php if ($toggleable): ?>
    <ui-dropdown position="<?php echo e($position); ?> <?php echo e($align); ?>" <?php echo e($attributes); ?> data-flux-tooltip>
        <?php echo e($slot); ?>


        <?php if ($content !== null): ?>
            <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/content.blade.php', $__blaze->compiledPath.'/8664675aca1b7221dfba57a0e222f216.php'); ?>
<?php if (isset($__slots8664675aca1b7221dfba57a0e222f216)) { $__slotsStack8664675aca1b7221dfba57a0e222f216[] = $__slots8664675aca1b7221dfba57a0e222f216; } ?>
<?php if (isset($__attrs8664675aca1b7221dfba57a0e222f216)) { $__attrsStack8664675aca1b7221dfba57a0e222f216[] = $__attrs8664675aca1b7221dfba57a0e222f216; } ?>
<?php $__attrs8664675aca1b7221dfba57a0e222f216 = ['kbd' => $kbd]; ?>
<?php $__slots8664675aca1b7221dfba57a0e222f216 = []; ?>
<?php $__blaze->pushData($__attrs8664675aca1b7221dfba57a0e222f216); ?>
<?php ob_start(); ?><?php echo e($content); ?><?php $__slots8664675aca1b7221dfba57a0e222f216['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots8664675aca1b7221dfba57a0e222f216); ?>
<?php _8664675aca1b7221dfba57a0e222f216($__blaze, $__attrs8664675aca1b7221dfba57a0e222f216, $__slots8664675aca1b7221dfba57a0e222f216, ['kbd'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack8664675aca1b7221dfba57a0e222f216)) { $__slots8664675aca1b7221dfba57a0e222f216 = array_pop($__slotsStack8664675aca1b7221dfba57a0e222f216); } ?>
<?php if (! empty($__attrsStack8664675aca1b7221dfba57a0e222f216)) { $__attrs8664675aca1b7221dfba57a0e222f216 = array_pop($__attrsStack8664675aca1b7221dfba57a0e222f216); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>
    </ui-dropdown>
<?php else: ?>
    <ui-tooltip position="<?php echo e($position); ?> <?php echo e($align); ?>" <?php echo e($attributes); ?> data-flux-tooltip <?php if($interactive): ?> interactive <?php endif; ?>>
        <?php echo e($slot); ?>


        <?php if ($content !== null): ?>
            <?php $__blaze->ensureRequired('C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/content.blade.php', $__blaze->compiledPath.'/8664675aca1b7221dfba57a0e222f216.php'); ?>
<?php if (isset($__slots8664675aca1b7221dfba57a0e222f216)) { $__slotsStack8664675aca1b7221dfba57a0e222f216[] = $__slots8664675aca1b7221dfba57a0e222f216; } ?>
<?php if (isset($__attrs8664675aca1b7221dfba57a0e222f216)) { $__attrsStack8664675aca1b7221dfba57a0e222f216[] = $__attrs8664675aca1b7221dfba57a0e222f216; } ?>
<?php $__attrs8664675aca1b7221dfba57a0e222f216 = ['kbd' => $kbd]; ?>
<?php $__slots8664675aca1b7221dfba57a0e222f216 = []; ?>
<?php $__blaze->pushData($__attrs8664675aca1b7221dfba57a0e222f216); ?>
<?php ob_start(); ?><?php echo e($content); ?><?php $__slots8664675aca1b7221dfba57a0e222f216['slot'] = new \Illuminate\View\ComponentSlot(trim(ob_get_clean()), []); ?>
<?php $__blaze->pushSlots($__slots8664675aca1b7221dfba57a0e222f216); ?>
<?php _8664675aca1b7221dfba57a0e222f216($__blaze, $__attrs8664675aca1b7221dfba57a0e222f216, $__slots8664675aca1b7221dfba57a0e222f216, ['kbd'], [], $__this ?? (isset($this) ? $this : null)); ?>
<?php if (! empty($__slotsStack8664675aca1b7221dfba57a0e222f216)) { $__slots8664675aca1b7221dfba57a0e222f216 = array_pop($__slotsStack8664675aca1b7221dfba57a0e222f216); } ?>
<?php if (! empty($__attrsStack8664675aca1b7221dfba57a0e222f216)) { $__attrs8664675aca1b7221dfba57a0e222f216 = array_pop($__attrsStack8664675aca1b7221dfba57a0e222f216); } ?>
<?php $__blaze->popData(); ?>
        <?php endif; ?>
    </ui-tooltip>
<?php endif; ?>
<?php
echo ltrim(ob_get_clean());
} endif; ?><?php /**PATH C:\laragon\www\bossed-landig-page\vendor\livewire\flux\src/../stubs/resources/views/flux/tooltip/index.blade.php ENDPATH**/ ?>