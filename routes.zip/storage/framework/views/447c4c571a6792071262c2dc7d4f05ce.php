<img src="<?php echo e(asset('assets/BOOSED_LOGO.png')); ?>" alt="">
<?php /**PATH C:\laragon\www\bossed-landig-page\resources\views/components/app-logo-icon.blade.php ENDPATH**/ ?>